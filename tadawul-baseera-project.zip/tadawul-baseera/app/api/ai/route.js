
const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY;

export async function POST(request) {
  try {
    const { prompt, stockData } = await request.json();
    
    if (!ANTHROPIC_KEY) {
      return Response.json({ error: "مفتاح Claude API غير مُعد" }, { status: 500 });
    }

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: "أنت محلل مالي سعودي محترف اسمك بصيرة. تحلل الأسهم السعودية بالعربية. مختصر وعملي ومنظم.",
        messages: [{ role: "user", content: `${prompt}\n\nبيانات السهم:\n${stockData}` }],
      }),
    });

    const data = await res.json();
    const text = data.content?.map(c => c.text || "").join("\n") || "خطأ في التحليل";
    
    return Response.json({ result: text });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
