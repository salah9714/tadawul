import { NextRequest, NextResponse } from "next/server";

/**
 * تداول بصيرة - API الذكاء الاصطناعي
 *
 * يوفر تكاملاً آمناً مع Claude API من جانب الخادم
 * مفتاح API محمي ولا يُكشف للمتصفح
 *
 * POST /api/ai
 * Body: { prompt: string, stockData?: object, type?: string }
 */

const SYSTEM_PROMPTS: Record<string, string> = {
  summary:
    "أنت محلل مالي سعودي محترف. قدم ملخصاً استثمارياً مختصراً ومنظماً بالعربية. كن عملياً واقترح إجراءات واضحة. لا تستخدم Markdown.",

  report:
    "أنت محلل مالي مؤسسي في بنك استثماري سعودي. اكتب تقارير احترافية بالعربية بأسلوب تقارير الأبحاث المؤسسية. منظمة ومفصلة ومدعومة بأرقام. لا تستخدم Markdown.",

  thesis:
    "أنت بانِ أطروحات استثمارية محترف. ابنِ أطروحات متكاملة تشمل: لماذا نشتري، المخاطر، المحفزات، السعر المستهدف، حجم المركز، ومتى نبيع. بالعربية. لا تستخدم Markdown.",

  chat:
    "أنت مساعد تحليل أسهم سعودي ذكي اسمك 'بصيرة'. تجيب بالعربية بشكل مختصر ومفيد وعملي. لديك بيانات كل الأسهم السعودية. اقترح إجراءات واضحة. لا تستخدم Markdown.",

  technical:
    "أنت محلل فني محترف في السوق السعودي. حلل المؤشرات الفنية واقترح خطة صفقة واضحة بنقاط الدخول والخروج. بالعربية. لا تستخدم Markdown.",

  risk:
    "أنت محلل مخاطر مالية محترف. قيّم المخاطر بشكل شامل مع اختبار ضغط وتوصيات تخفيف المخاطر. بالعربية. لا تستخدم Markdown.",

  compare:
    "أنت محلل مقارنات مالية. قارن الأسهم بشكل موضوعي من كل الزوايا وقدم توصية واضحة. بالعربية. لا تستخدم Markdown.",
};

export async function POST(request: NextRequest) {
  try {
    const apiKey = process.env.ANTHROPIC_API_KEY;

    if (!apiKey) {
      return NextResponse.json(
        { error: "مفتاح API غير مُعد. أضف ANTHROPIC_API_KEY في .env.local" },
        { status: 500 }
      );
    }

    const body = await request.json();
    const { prompt, stockData, type = "summary" } = body;

    if (!prompt) {
      return NextResponse.json(
        { error: "الرجاء إرسال نص الطلب (prompt)" },
        { status: 400 }
      );
    }

    // اختيار نمط النظام المناسب
    const systemPrompt = SYSTEM_PROMPTS[type] || SYSTEM_PROMPTS.summary;

    // بناء رسالة المستخدم مع بيانات السهم إن وُجدت
    let userMessage = prompt;
    if (stockData) {
      userMessage += `\n\nبيانات السهم:\n${JSON.stringify(stockData, null, 0)}`;
    }

    // استدعاء Claude API
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1500,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }],
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("Claude API Error:", error);
      return NextResponse.json(
        { error: "خطأ في الاتصال بالذكاء الاصطناعي" },
        { status: 502 }
      );
    }

    const data = await response.json();
    const text = data.content
      ?.map((block: any) => block.text || "")
      .filter(Boolean)
      .join("\n");

    return NextResponse.json({
      text: text || "لم يتم الحصول على نتيجة",
      model: data.model,
      usage: data.usage,
    });
  } catch (error) {
    console.error("AI API Error:", error);
    return NextResponse.json(
      { error: "حدث خطأ داخلي" },
      { status: 500 }
    );
  }
}
