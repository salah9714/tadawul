import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // Fetch TASI index
    const url = 'https://query1.finance.yahoo.com/v8/finance/chart/%5ETASI.SR?interval=1d&range=1mo';
    const res = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
      next: { revalidate: 300 }
    });
    const data = await res.json();
    const result = data.chart?.result?.[0];
    const meta = result?.meta || {};
    const closes = result?.indicators?.quote?.[0]?.close?.filter(v => v != null) || [];

    return NextResponse.json({
      tasi: {
        value: Math.round(meta.regularMarketPrice || 11090),
        change: Math.round((meta.regularMarketPrice - meta.previousClose) / meta.previousClose * 10000) / 100,
        prices: closes.slice(-30).map(v => Math.round(v)),
      },
      updated: new Date().toISOString(),
    });
  } catch (e) {
    return NextResponse.json({ tasi: { value: 11090, change: 0, prices: [] } });
  }
}
