
const API_KEY = process.env.TWELVE_DATA_API_KEY || "demo";
const BASE = "https://api.twelvedata.com";

const STOCKS = {
  "2222": { name: "أرامكو", en: "Aramco", sector: "الطاقة" },
  "1120": { name: "الراجحي", en: "Al Rajhi", sector: "البنوك" },
  "1180": { name: "الأهلي", en: "SNB", sector: "البنوك" },
  "2010": { name: "سابك", en: "SABIC", sector: "المواد" },
  "7010": { name: "STC", en: "STC", sector: "الاتصالات" },
  "4030": { name: "البحري", en: "Bahri", sector: "النقل" },
  "4190": { name: "جرير", en: "Jarir", sector: "التجزئة" },
  "4200": { name: "الدريس", en: "Aldrees", sector: "الطاقة" },
  "2350": { name: "كيان", en: "Kayan", sector: "المواد" },
  "1010": { name: "الرياض", en: "Riyad Bank", sector: "البنوك" },
  "2280": { name: "المراعي", en: "Almarai", sector: "الأغذية" },
  "8010": { name: "التعاونية", en: "Tawuniya", sector: "التأمين" },
  "2060": { name: "التصنيع", en: "Tasnee", sector: "المواد" },
  "4260": { name: "بدجت", en: "Budget", sector: "النقل" },
  "1150": { name: "البنك الأول", en: "SAB", sector: "البنوك" },
  "2150": { name: "زين", en: "Zain KSA", sector: "الاتصالات" },
  "3010": { name: "أسمنت العربية", en: "Arabian Cement", sector: "الأسمنت" },
  "4001": { name: "الجنوبية", en: "Southern Cement", sector: "الأسمنت" },
  "4002": { name: "المتقدمة", en: "APPC", sector: "المواد" },
  "2050": { name: "صافولا", en: "Savola", sector: "الأغذية" },
};

async function fetchQuote(code) {
  try {
    const res = await fetch(`${BASE}/quote?symbol=${code}.SR&apikey=${API_KEY}`, { next: { revalidate: 60 } });
    const d = await res.json();
    if (d.status === "error") return null;
    return {
      price: +d.close || 0,
      open: +d.open || 0,
      high: +d.high || 0,
      low: +d.low || 0,
      volume: +d.volume || 0,
      change: +d.change || 0,
      changePct: +d.percent_change || 0,
      prevClose: +d.previous_close || 0,
      time: d.datetime,
    };
  } catch { return null; }
}

async function fetchHistory(code, days = 30) {
  try {
    const res = await fetch(`${BASE}/time_series?symbol=${code}.SR&interval=1day&outputsize=${days}&apikey=${API_KEY}`, { next: { revalidate: 300 } });
    const d = await res.json();
    if (d.status === "error") return [];
    return (d.values || []).map(v => ({
      date: v.datetime, close: +v.close, volume: +v.volume,
    })).reverse();
  } catch { return []; }
}

async function fetchRSI(code) {
  try {
    const res = await fetch(`${BASE}/rsi?symbol=${code}.SR&interval=1day&time_period=14&outputsize=1&apikey=${API_KEY}`, { next: { revalidate: 300 } });
    const d = await res.json();
    return d.values?.[0]?.rsi ? Math.round(+d.values[0].rsi) : null;
  } catch { return null; }
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get("code");
  const type = searchParams.get("type") || "quote";

  try {
    if (code) {
      const info = STOCKS[code];
      if (!info) return Response.json({ error: "سهم غير موجود" }, { status: 404 });
      
      const result = { code, ...info };
      if (type === "quote" || type === "all") result.quote = await fetchQuote(code);
      if (type === "history" || type === "all") result.history = await fetchHistory(code);
      if (type === "indicators" || type === "all") result.rsi = await fetchRSI(code);
      
      return Response.json(result);
    }

    // جلب أسعار كل الأسهم
    const codes = Object.keys(STOCKS);
    const symbols = codes.map(c => `${c}.SR`).join(",");
    
    // Twelve Data يدعم طلب عدة أسهم في طلب واحد
    const res = await fetch(`${BASE}/quote?symbol=${symbols}&apikey=${API_KEY}`, { next: { revalidate: 60 } });
    const data = await res.json();
    
    const stocks = {};
    for (const code of codes) {
      const key = `${code}.SR`;
      const d = data[key] || data;
      if (d && d.close) {
        stocks[code] = {
          code,
          ...STOCKS[code],
          price: +d.close || 0,
          change: +d.change || 0,
          changePct: +d.percent_change || 0,
          volume: +d.volume || 0,
          high: +d.high || 0,
          low: +d.low || 0,
        };
      }
    }

    return Response.json({
      updated: new Date().toISOString(),
      count: Object.keys(stocks).length,
      stocks,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
