import './globals.css';

export const metadata = {
  title: 'تداول بصيرة | التحليل الذكي للأسهم السعودية',
  description: 'نظام تحليل ذكي للأسهم السعودية مع بيانات حية من تداول',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
