import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "تداول بصيرة | التحليل الذكي للأسهم السعودية",
  description:
    "نظام تحليل مالي متكامل مصمم خصيصاً للسوق السعودي - تداول الرئيسي ونمو",
  keywords: "أسهم سعودية، تداول، تحليل مالي، تحليل فني، توزيعات",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-slate-950 text-slate-200 font-tajawal antialiased">
        {children}
      </body>
    </html>
  );
}
