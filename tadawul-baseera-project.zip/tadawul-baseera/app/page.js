
"use client";
import { useState, useEffect, useCallback } from "react";
import { TrendingUp, TrendingDown, Search, RefreshCw, Brain, Briefcase, Activity, Filter, Bell, Home, Layers, Settings, ChevronRight, ChevronLeft, Star, AlertTriangle } from "lucide-react";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const K = { nv:"#0f1729", gd:"#d4a84b", bl:"#3b82f6", gn:"#10b981", rd:"#ef4444", tx:"#e2e8f0", dm:"#94a3b8", cd:"#1e293b", bd:"#334155", bg:"#0b1120" };
const PC = ["#3b82f6","#10b981","#d4a84b","#ef4444","#8b5cf6","#06b6d4","#f59e0b","#ec4899"];

export default function App() {
  const [stocks, setStocks] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [selectedStock, setSelectedStock] = useState(null);
  const [stockDetail, setStockDetail] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [aiResult, setAiResult] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState("dashboard");

  // جلب كل الأسعار
  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/stocks");
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setStocks(data.stocks || {});
      setLastUpdate(new Date().toLocaleTimeString("ar-SA"));
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  }, []);

  // جلب تفاصيل سهم
  const fetchDetail = useCallback(async (code) => {
    setSelectedStock(code);
    setPage("stock");
    setDetailLoading(true);
    setAiResult("");
    try {
      const res = await fetch(`/api/stocks?code=${code}&type=all`);
      setStockDetail(await res.json());
    } catch (e) {
      console.error(e);
    }
    setDetailLoading(false);
  }, []);

  // تحليل AI
  const runAI = useCallback(async (prompt) => {
    if (!stockDetail) return;
    setAiLoading(true);
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          stockData: JSON.stringify(stockDetail, null, 2),
        }),
      });
      const data = await res.json();
      setAiResult(data.result || data.error || "خطأ");
    } catch {
      setAiResult("حدث خطأ في التحليل");
    }
    setAiLoading(false);
  }, [stockDetail]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  // Auto-refresh every 60 seconds
  useEffect(() => {
    const interval = setInterval(fetchAll, 60000);
    return () => clearInterval(interval);
  }, [fetchAll]);

  const stockList = Object.values(stocks);
  const gainers = stockList.filter(s => s.changePct > 0).length;
  const losers = stockList.filter(s => s.changePct < 0).length;
  const filtered = search ? stockList.filter(s => s.name.includes(search) || s.en.toLowerCase().includes(search.toLowerCase()) || s.code.includes(search)) : [];

  const Cd = ({children, style}) => <div style={{background:K.cd, borderRadius:10, border:`1px solid ${K.bd}`, overflow:"hidden", ...style}}>{children}</div>;

  return (
    <div dir="rtl" style={{display:"flex", height:"100vh", background:K.bg, color:K.tx, fontFamily:"'Segoe UI',Tahoma,sans-serif", fontSize:12}}>
      
      {/* SIDEBAR */}
      <div style={{width:180, background:K.nv, borderLeft:`1px solid ${K.bd}`, display:"flex", flexDirection:"column", flexShrink:0}}>
        <div style={{padding:"12px", borderBottom:`1px solid ${K.bd}`}}>
          <div style={{fontSize:15, fontWeight:800, color:K.gd}}>تداول بصيرة</div>
          <div style={{fontSize:8, color:K.dm}}>بيانات حية من تداول</div>
        </div>
        <div style={{flex:1, paddingTop:4}}>
          {[{id:"dashboard",l:"لوحة القيادة",ic:Home},{id:"stock",l:"ملف السهم",ic:Activity},{id:"screener",l:"الفلاتر",ic:Filter}].map(n => (
            <div key={n.id} onClick={() => setPage(n.id)} style={{display:"flex",alignItems:"center",gap:7,padding:"7px 10px",margin:"1px 4px",borderRadius:6,cursor:"pointer",background:page===n.id?`${K.gd}15`:"transparent",color:page===n.id?K.gd:K.dm}}>
              <n.ic size={14}/><span style={{fontSize:11,fontWeight:page===n.id?600:400}}>{n.l}</span>
            </div>
          ))}
        </div>
        <div style={{padding:8, borderTop:`1px solid ${K.bd}`, fontSize:8, color:K.dm, textAlign:"center"}}>
          {lastUpdate && `آخر تحديث: ${lastUpdate}`}
        </div>
      </div>

      {/* MAIN */}
      <div style={{flex:1, display:"flex", flexDirection:"column", overflow:"hidden"}}>
        {/* TOP BAR */}
        <div style={{background:K.nv, borderBottom:`1px solid ${K.bd}`, padding:"6px 14px", display:"flex", alignItems:"center", justifyContent:"space-between", gap:10, flexShrink:0}}>
          <div style={{position:"relative", flex:1, maxWidth:300}}>
            <Search size={13} style={{position:"absolute", right:8, top:7, color:K.dm}}/>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث عن سهم..." style={{width:"100%", background:K.cd, border:`1px solid ${K.bd}`, borderRadius:6, padding:"6px 26px 6px 8px", color:K.tx, fontSize:11, outline:"none"}}/>
            {search && filtered.length > 0 && (
              <div style={{position:"absolute", top:30, right:0, left:0, background:K.cd, border:`1px solid ${K.bd}`, borderRadius:6, zIndex:100, maxHeight:200, overflowY:"auto", boxShadow:"0 6px 20px rgba(0,0,0,.5)"}}>
                {filtered.map(s => (
                  <div key={s.code} onClick={() => { fetchDetail(s.code); setSearch(""); }} style={{display:"flex", justifyContent:"space-between", padding:"7px 10px", cursor:"pointer", borderBottom:`1px solid ${K.bd}`, fontSize:11}}>
                    <strong>{s.name} ({s.code})</strong>
                    <span style={{color:s.changePct >= 0 ? K.gn : K.rd}}>{s.price} ({s.changePct >= 0 ? "+" : ""}{s.changePct?.toFixed(2)}%)</span>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div style={{display:"flex", alignItems:"center", gap:10, fontSize:10}}>
            <span style={{color:K.gn}}>{gainers}↑</span>
            <span style={{color:K.rd}}>{losers}↓</span>
            <button onClick={fetchAll} disabled={loading} style={{background:"none", border:"none", color:K.gd, cursor:"pointer", padding:4}}>
              <RefreshCw size={14} style={{animation: loading ? "spin 1s linear infinite" : "none"}}/>
            </button>
            <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
            <span style={{background:`${K.gn}20`, color:K.gn, padding:"2px 8px", borderRadius:10, fontSize:9, fontWeight:600}}>LIVE بيانات حية</span>
          </div>
        </div>

        {/* CONTENT */}
        <div style={{flex:1, overflowY:"auto", padding:"12px 16px"}}>
          
          {error && (
            <Cd style={{padding:12, marginBottom:12, borderRight:`3px solid ${K.rd}`}}>
              <div style={{display:"flex", alignItems:"center", gap:6, color:K.rd}}>
                <AlertTriangle size={14}/> 
                <span>خطأ: {error}</span>
                <button onClick={fetchAll} style={{background:`${K.bl}20`, border:`1px solid ${K.bl}40`, borderRadius:6, padding:"3px 8px", color:K.bl, cursor:"pointer", fontSize:10, marginRight:8}}>إعادة المحاولة</button>
              </div>
            </Cd>
          )}

          {/* DASHBOARD */}
          {page === "dashboard" && (
            <div>
              <h2 style={{fontSize:17, fontWeight:700, color:K.gd, margin:"0 0 12px"}}>
                لوحة القيادة 
                {loading && <RefreshCw size={14} style={{display:"inline", marginRight:8, animation:"spin 1s linear infinite", color:K.gd}}/>}
              </h2>

              {/* Stats */}
              <div style={{display:"flex", gap:8, marginBottom:12, flexWrap:"wrap"}}>
                {[
                  {l:"عدد الأسهم", v:stockList.length, c:K.bl},
                  {l:"مرتفعة", v:gainers, c:K.gn},
                  {l:"منخفضة", v:losers, c:K.rd},
                ].map((m,i) => (
                  <Cd key={i} style={{padding:"10px 14px", flex:1, minWidth:100}}>
                    <div style={{color:K.dm, fontSize:10, marginBottom:4}}>{m.l}</div>
                    <div style={{fontSize:20, fontWeight:700, color:m.c}}>{m.v}</div>
                  </Cd>
                ))}
              </div>

              {/* Stock Table */}
              <Cd>
                <div style={{padding:"8px 12px", borderBottom:`1px solid ${K.bd}`, fontWeight:600, fontSize:12, display:"flex", justifyContent:"space-between"}}>
                  <span>أسهم السوق السعودي - أسعار حية</span>
                  <span style={{color:K.dm, fontSize:9}}>{lastUpdate}</span>
                </div>
                {loading && stockList.length === 0 ? (
                  <div style={{padding:30, textAlign:"center", color:K.dm}}>
                    <RefreshCw size={20} style={{animation:"spin 1s linear infinite", marginBottom:8}}/><br/>
                    جاري جلب البيانات من السوق...
                  </div>
                ) : (
                  <div style={{overflowX:"auto"}}>
                    <table style={{width:"100%", borderCollapse:"collapse", fontSize:11}}>
                      <thead>
                        <tr style={{background:K.nv}}>
                          {["الرمز","الاسم","القطاع","السعر","التغير","الأعلى","الأدنى","الحجم"].map(h => (
                            <th key={h} style={{padding:"7px 8px", textAlign:"right", color:K.dm, fontSize:9, fontWeight:600}}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {stockList.sort((a,b) => (b.changePct || 0) - (a.changePct || 0)).map((s, i) => (
                          <tr key={s.code} onClick={() => fetchDetail(s.code)} style={{cursor:"pointer", borderBottom:`1px solid ${K.bd}`}} 
                            onMouseEnter={e => e.currentTarget.style.background = "#263348"} 
                            onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                            <td style={{padding:"7px 8px", fontWeight:600}}>{s.code}</td>
                            <td style={{padding:"7px 8px"}}>{s.name}</td>
                            <td style={{padding:"7px 8px", color:K.dm}}>{s.sector}</td>
                            <td style={{padding:"7px 8px", fontWeight:700}}>{s.price?.toFixed(2)}</td>
                            <td style={{padding:"7px 8px", color:(s.changePct||0) >= 0 ? K.gn : K.rd, fontWeight:600}}>
                              {(s.changePct||0) >= 0 ? "+" : ""}{s.changePct?.toFixed(2)}%
                            </td>
                            <td style={{padding:"7px 8px"}}>{s.high?.toFixed(2)}</td>
                            <td style={{padding:"7px 8px"}}>{s.low?.toFixed(2)}</td>
                            <td style={{padding:"7px 8px", color:K.dm}}>{s.volume ? (s.volume/1e6).toFixed(1)+"M" : "-"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </Cd>
            </div>
          )}

          {/* STOCK DETAIL */}
          {page === "stock" && (
            <div>
              {detailLoading ? (
                <div style={{padding:40, textAlign:"center", color:K.gd}}>
                  <RefreshCw size={20} style={{animation:"spin 1s linear infinite"}}/><br/>
                  جاري جلب بيانات السهم...
                </div>
              ) : stockDetail ? (
                <div>
                  {/* Header */}
                  <div style={{display:"flex", justifyContent:"space-between", marginBottom:12}}>
                    <div>
                      <h2 style={{fontSize:20, fontWeight:700, margin:0}}>{stockDetail.name} <span style={{color:K.dm, fontSize:12}}>({stockDetail.code})</span></h2>
                      <span style={{color:K.dm, fontSize:11}}>{stockDetail.en} · {stockDetail.sector}</span>
                    </div>
                    {stockDetail.quote && (
                      <div style={{textAlign:"left"}}>
                        <div style={{fontSize:26, fontWeight:800}}>{stockDetail.quote.price?.toFixed(2)} <span style={{fontSize:11, color:K.dm}}>ر.س</span></div>
                        <div style={{fontSize:14, color:(stockDetail.quote.changePct||0) >= 0 ? K.gn : K.rd}}>
                          {(stockDetail.quote.changePct||0) >= 0 ? "+" : ""}{stockDetail.quote.changePct?.toFixed(2)}%
                          ({(stockDetail.quote.change||0) >= 0 ? "+" : ""}{stockDetail.quote.change?.toFixed(2)})
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Quick Stats */}
                  {stockDetail.quote && (
                    <div style={{display:"flex", gap:6, marginBottom:12, flexWrap:"wrap"}}>
                      {[
                        {l:"الافتتاح", v:stockDetail.quote.open?.toFixed(2)},
                        {l:"الأعلى", v:stockDetail.quote.high?.toFixed(2)},
                        {l:"الأدنى", v:stockDetail.quote.low?.toFixed(2)},
                        {l:"الإغلاق السابق", v:stockDetail.quote.prevClose?.toFixed(2)},
                        {l:"الحجم", v:stockDetail.quote.volume ? (stockDetail.quote.volume/1e6).toFixed(1)+"M" : "-"},
                        {l:"RSI", v:stockDetail.rsi || "-"},
                      ].map((m,i) => (
                        <Cd key={i} style={{padding:"8px 12px", flex:1, minWidth:90}}>
                          <div style={{color:K.dm, fontSize:9}}>{m.l}</div>
                          <div style={{fontSize:15, fontWeight:700}}>{m.v}</div>
                        </Cd>
                      ))}
                    </div>
                  )}

                  {/* Price Chart */}
                  {stockDetail.history && stockDetail.history.length > 0 && (
                    <Cd style={{padding:10, marginBottom:12}}>
                      <div style={{fontSize:11, fontWeight:600, marginBottom:6}}>السعر - آخر {stockDetail.history.length} يوم (بيانات حية)</div>
                      <ResponsiveContainer width="100%" height={200}>
                        <AreaChart data={stockDetail.history}>
                          <defs>
                            <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor={K.gn} stopOpacity={0.2}/>
                              <stop offset="100%" stopColor={K.gn} stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke={K.bd} opacity={0.3}/>
                          <XAxis dataKey="date" tick={{fill:K.dm, fontSize:8}} axisLine={false} tickFormatter={v => v?.slice(5)}/>
                          <YAxis tick={{fill:K.dm, fontSize:8}} axisLine={false} domain={["auto","auto"]}/>
                          <Tooltip contentStyle={{background:K.nv, border:`1px solid ${K.bd}`, borderRadius:6, fontSize:10}} formatter={v => [`${v?.toFixed(2)} ر.س`]}/>
                          <Area type="monotone" dataKey="close" stroke={K.gn} fill="url(#cg)" strokeWidth={2}/>
                        </AreaChart>
                      </ResponsiveContainer>
                    </Cd>
                  )}

                  {/* AI Analysis */}
                  <Cd style={{padding:14}}>
                    <div style={{display:"flex", alignItems:"center", gap:5, marginBottom:10}}>
                      <Brain size={14} color={K.gd}/>
                      <span style={{fontSize:12, fontWeight:600, color:K.gd}}>تحليل الذكاء الاصطناعي</span>
                    </div>
                    <div style={{display:"flex", gap:4, marginBottom:10, flexWrap:"wrap"}}>
                      {[
                        {l:"ملخص شامل", p:"قدم ملخصاً استثمارياً شاملاً لهذا السهم"},
                        {l:"هل أشتري؟", p:"هل تنصح بشراء هذا السهم الآن؟ ولماذا؟"},
                        {l:"المخاطر", p:"ما أهم مخاطر هذا السهم؟"},
                        {l:"نقاط القوة", p:"ما نقاط القوة في هذا السهم؟"},
                      ].map(b => (
                        <button key={b.l} onClick={() => runAI(b.p)} disabled={aiLoading} style={{padding:"5px 10px", borderRadius:6, border:`1px solid ${K.gd}40`, background:`${K.gd}15`, color:K.gd, cursor:aiLoading?"wait":"pointer", fontSize:10, fontWeight:600, opacity:aiLoading?.5:1}}>{b.l}</button>
                      ))}
                    </div>
                    {aiLoading && <div style={{color:K.gd, padding:16, textAlign:"center", fontSize:11}}><RefreshCw size={13} style={{animation:"spin 1s linear infinite"}}/> جاري التحليل...</div>}
                    {aiResult && !aiLoading && <div style={{background:K.nv, borderRadius:8, padding:12, border:`1px solid ${K.gd}20`, whiteSpace:"pre-wrap", fontSize:11, lineHeight:1.9}}>{aiResult}</div>}
                  </Cd>
                </div>
              ) : (
                <div style={{padding:40, textAlign:"center", color:K.dm}}>اختر سهماً من لوحة القيادة أو ابحث عنه</div>
              )}
            </div>
          )}

          {/* SCREENER */}
          {page === "screener" && (
            <div>
              <h2 style={{fontSize:17, fontWeight:700, color:K.gd, margin:"0 0 12px"}}>الفلاتر</h2>
              <Cd>
                <div style={{overflowX:"auto"}}>
                  <table style={{width:"100%", borderCollapse:"collapse", fontSize:11}}>
                    <thead>
                      <tr style={{background:K.nv}}>
                        {["الرمز","الاسم","القطاع","السعر","التغير %","الحجم"].map(h => (
                          <th key={h} style={{padding:"7px 8px", textAlign:"right", color:K.dm, fontSize:9}}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {stockList.sort((a,b) => (b.changePct||0) - (a.changePct||0)).map(s => (
                        <tr key={s.code} onClick={() => fetchDetail(s.code)} style={{cursor:"pointer", borderBottom:`1px solid ${K.bd}`}}>
                          <td style={{padding:"7px 8px", fontWeight:600}}>{s.code}</td>
                          <td style={{padding:"7px 8px"}}>{s.name}</td>
                          <td style={{padding:"7px 8px", color:K.dm}}>{s.sector}</td>
                          <td style={{padding:"7px 8px", fontWeight:600}}>{s.price?.toFixed(2)}</td>
                          <td style={{padding:"7px 8px", color:(s.changePct||0)>=0?K.gn:K.rd, fontWeight:600}}>{(s.changePct||0)>=0?"+":""}{s.changePct?.toFixed(2)}%</td>
                          <td style={{padding:"7px 8px"}}>{s.volume?(s.volume/1e6).toFixed(1)+"M":"-"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Cd>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
