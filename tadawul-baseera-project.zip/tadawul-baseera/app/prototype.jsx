import { useState, useCallback, useMemo, useRef, useEffect } from "react";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ComposedChart, Legend, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from "recharts";
import { TrendingUp, TrendingDown, Search, BarChart3, Bell, FileText, Settings, Home, Filter, Briefcase, DollarSign, Layers, ChevronLeft, ChevronRight, Star, AlertTriangle, Activity, Zap, Eye, Brain, RefreshCw, X, Plus, Copy, GitCompare, Calendar, Target, Award, CheckCircle, XCircle, Trash2, BookOpen, MessageCircle, Globe, Send, Volume2 } from "lucide-react";

// ═══════════ 20 STOCKS ═══════════
const S={
"2222":{n:"أرامكو",en:"Aramco",s:"الطاقة",p:28.45,ch:1.25,v:18.5,mc:9520,pe:15.2,pb:3.1,dy:6.8,roe:32.5,de:.25,bt:.85,eps:1.87,fcf:380,ds:92,sc:82,rsi:58,m50:27.9,m200:27.2,sp:27.5,rs:29,tr:"صاعد",nm:30,ng:12,dg:5,pr:[27.1,27.3,27,27.5,27.8,28,27.6,27.9,28.2,28,28.3,28.1,28.5,28.3,28.6,28.4,28.7,28.5,28.2,28.4,28.6,28.3,28.5,28.45],vl:[18,20,15,22,19,21,17,23,18,20,16,19,22,18,21,17,24,19,16,20,18,22,19,18],er:[{q:"Q1-25",a:1.95,e:1.85,rx:2.1},{q:"Q4-24",a:1.82,e:1.9,rx:-1.5}],dh:[{y:"24",a:1.92},{y:"23",a:1.80},{y:"22",a:1.70},{y:"21",a:1.56}],moat:"أقل تكلفة إنتاج عالمياً",risk:"تقلب النفط"},
"1180":{n:"الأهلي",en:"SNB",s:"البنوك",p:38.70,ch:-.51,v:4.2,mc:198,pe:11.8,pb:2.1,dy:3.2,roe:18.5,de:0,bt:.92,eps:3.28,fcf:20,ds:88,sc:78,rsi:52,m50:38.4,m200:37.8,sp:37.5,rs:39.5,tr:"عرضي",nm:52,ng:9,dg:7,pr:[37.5,37.8,38,38.2,37.9,38.1,38.4,38.6,38.3,38.5,38.8,38.6,38.9,38.7,39,38.8,38.5,38.7,38.9,38.6,38.8,38.5,38.7,38.7],vl:[4,5,3,6,4,5,4,6,3,5,4,5,6,4,5,3,6,4,5,4,5,3,4,4],er:[{q:"Q1-25",a:3.45,e:3.3,rx:1.2}],dh:[{y:"24",a:1.24},{y:"23",a:1.16},{y:"22",a:1.08}],moat:"أكبر بنك سعودي",risk:"حساسية فائدة"},
"1120":{n:"الراجحي",en:"Al Rajhi",s:"البنوك",p:96.50,ch:1.9,v:5.8,mc:385,pe:17.5,pb:3.8,dy:2.8,roe:22.1,de:0,bt:1.05,eps:5.51,fcf:15,ds:85,sc:75,rsi:65,m50:94.8,m200:92.5,sp:93,rs:98.5,tr:"صاعد",nm:59,ng:14,dg:8,pr:[92,92.5,93,93.5,93,93.8,94.2,94,94.5,95,94.5,95.2,95.8,95.5,96,95.5,96.2,95.8,96,96.5,96,96.3,96.2,96.5],vl:[6,7,5,8,6,7,5,8,6,7,5,6,8,6,7,5,8,6,5,7,6,7,5,6],er:[{q:"Q1-25",a:5.8,e:5.5,rx:2.5}],dh:[{y:"24",a:2.7},{y:"23",a:2.5},{y:"22",a:2.3}],moat:"أكبر بنك إسلامي",risk:"تقييم مرتفع"},
"2010":{n:"سابك",en:"SABIC",s:"المواد",p:72.30,ch:-1.09,v:3.1,mc:216,pe:22.5,pb:1.6,dy:4.1,roe:8.2,de:.35,bt:1.15,eps:3.21,fcf:8,ds:65,sc:58,rsi:42,m50:73.1,m200:74.5,sp:71,rs:74,tr:"هابط",nm:8,ng:-15,dg:-3,pr:[74,73.5,73.8,73.2,73.5,73,72.8,73.1,72.5,72.8,72.3,72.6,72,72.3,71.8,72.1,72.5,72.2,72.6,72.3,72.5,72.1,72.4,72.3],vl:[3,4,3,4,3,3,4,3,4,3,3,4,3,3,4,3,3,4,3,3,4,3,3,3],er:[{q:"Q1-25",a:3,e:3.3,rx:-2.5}],dh:[{y:"24",a:3},{y:"23",a:3.2},{y:"22",a:3.5}],moat:"حجم إنتاج ضخم",risk:"دورة هابطة"},
"7010":{n:"STC",en:"STC",s:"الاتصالات",p:43.85,ch:1.27,v:6.2,mc:219,pe:20.1,pb:3.2,dy:4.6,roe:16.8,de:.45,bt:.78,eps:2.18,fcf:11,ds:80,sc:72,rsi:61,m50:43.2,m200:42.5,sp:42.5,rs:44.5,tr:"صاعد",nm:18,ng:6,dg:4,pr:[42.5,42.8,43,42.7,43.2,43,43.4,43.2,43.5,43.3,43.6,43.4,43.7,43.5,43.8,43.5,43.7,43.4,43.6,43.8,43.5,43.7,43.9,43.85],vl:[6,7,5,8,6,7,5,8,6,7,5,6,8,6,7,5,8,6,5,7,6,7,5,6],er:[{q:"Q1-25",a:2.25,e:2.15,rx:1.5}],dh:[{y:"24",a:2},{y:"23",a:1.9},{y:"22",a:1.8}],moat:"بنية تحتية مهيمنة",risk:"ديون مرتفعة"},
"4030":{n:"البحري",en:"Bahri",s:"النقل",p:35.20,ch:2.62,v:2.8,mc:46,pe:9.8,pb:1.8,dy:5.5,roe:19.2,de:.4,bt:.88,eps:3.59,fcf:4.5,ds:78,sc:80,rsi:68,m50:34.5,m200:33.8,sp:34,rs:36,tr:"صاعد",nm:23,ng:18,dg:10,pr:[33.5,33.8,34,33.7,34.2,34,34.5,34.3,34.6,34.8,34.5,34.9,35,34.8,35.2,34.9,35.1,34.8,35,35.3,35,35.2,35.1,35.2],vl:[3,3,2,4,3,3,2,4,3,3,2,3,4,3,3,2,4,3,2,3,3,3,2,3],er:[{q:"Q1-25",a:3.8,e:3.5,rx:3.2}],dh:[{y:"24",a:1.94},{y:"23",a:1.75},{y:"22",a:1.5}],moat:"أكبر أسطول نقل إقليمي",risk:"دورة شحن"},
"4190":{n:"جرير",en:"Jarir",s:"التجزئة",p:152.60,ch:1.6,v:.68,mc:18.3,pe:22.8,pb:12.5,dy:3.5,roe:55.2,de:.1,bt:.7,eps:6.69,fcf:1,ds:90,sc:85,rsi:63,m50:150.5,m200:148,sp:149,rs:155,tr:"صاعد",nm:13,ng:8,dg:6,pr:[148,148.5,149,149.5,149,150,150.5,150,151,150.5,151.5,151,152,151.5,152,151.5,152.5,152,152.5,152,152.5,152,152.4,152.6],vl:[.7,.8,.6,.9,.7,.8,.6,.9,.7,.8,.6,.7,.9,.7,.8,.6,.9,.7,.6,.8,.7,.7,.6,.7],er:[{q:"Q1-25",a:7,e:6.8,rx:1.8}],dh:[{y:"24",a:5.3},{y:"23",a:5},{y:"22",a:4.7}],moat:"ROE 55%، كفاءة استثنائية",risk:"تقييم مرتفع"},
"4200":{n:"الدريس",en:"Aldrees",s:"الطاقة",p:88.40,ch:.68,v:.45,mc:7.5,pe:14.2,pb:3.5,dy:4.8,roe:25.1,de:.3,bt:.65,eps:6.23,fcf:1.8,ds:85,sc:77,rsi:55,m50:87.5,m200:86,sp:86.5,rs:90,tr:"صاعد",nm:10,ng:7,dg:6,pr:[86.5,86.8,87,87.3,87.5,87.2,87.8,87.5,88,87.8,88.2,88,88.4,88.1,88.3,88,88.2,88.5,88.3,88.5,88.2,88.4,88.3,88.4],vl:[.5,.6,.4,.6,.5,.5,.4,.6,.5,.5,.4,.5,.6,.5,.5,.4,.6,.5,.4,.5,.5,.5,.4,.5],er:[{q:"Q1-25",a:6.5,e:6.2,rx:1.2}],dh:[{y:"24",a:4.25},{y:"23",a:4}],moat:"شبكة توزيع وقود",risk:"تحول طاقة"},
"2350":{n:"كيان",en:"Kayan",s:"المواد",p:12.44,ch:-1.43,v:8.9,mc:18.7,pe:45.2,pb:.9,dy:1.2,roe:2.1,de:.55,bt:1.35,eps:.28,fcf:-.2,ds:30,sc:35,rsi:35,m50:12.7,m200:13.2,sp:12,rs:13,tr:"هابط",nm:3,ng:-25,dg:-10,pr:[13,12.9,12.8,12.9,12.7,12.8,12.6,12.7,12.5,12.6,12.4,12.5,12.3,12.4,12.5,12.3,12.4,12.3,12.5,12.4,12.3,12.5,12.4,12.44],vl:[9,10,8,11,9,10,8,11,9,10,8,9,11,9,10,8,11,9,8,10,9,9,8,9],er:[{q:"Q1-25",a:.2,e:.3,rx:-3}],dh:[{y:"24",a:.15},{y:"23",a:.2}],moat:"تكامل مع سابك",risk:"ديون، أرباح ضعيفة"},
"1010":{n:"الرياض",en:"Riyad",s:"البنوك",p:28.95,ch:1.58,v:3.8,mc:86.8,pe:12.2,pb:1.9,dy:3.8,roe:16.2,de:0,bt:.95,eps:2.37,fcf:8.8,ds:86,sc:76,rsi:59,m50:28.5,m200:27.8,sp:28,rs:30,tr:"صاعد",nm:53,ng:11,dg:8,pr:[27.8,28,28.2,28,28.3,28.5,28.3,28.6,28.4,28.7,28.5,28.8,28.6,28.9,28.7,29,28.8,28.7,28.9,28.7,29,28.8,28.9,28.95],vl:[4,4,3,5,4,4,3,5,4,4,3,4,5,4,4,3,5,4,3,4,4,4,3,4],er:[{q:"Q1-25",a:2.5,e:2.4,rx:1.5}],dh:[{y:"24",a:1.1},{y:"23",a:1}],moat:"رأسمال قوي",risk:"فائدة"},
"2280":{n:"المراعي",en:"Almarai",s:"الأغذية",p:54.20,ch:.56,v:1.2,mc:54.2,pe:21.5,pb:4.2,dy:2.2,roe:20.1,de:.35,bt:.55,eps:2.52,fcf:2.5,ds:82,sc:74,rsi:54,m50:53.8,m200:52.5,sp:52.5,rs:56,tr:"صاعد",nm:16,ng:9,dg:5,pr:[52.5,52.8,53,53.3,53.5,53.2,53.6,53.4,53.8,53.6,54,53.8,54.2,54,54.3,54.1,54,53.8,54.1,53.9,54.2,54,54.1,54.2],vl:[1.2,1.3,1,1.5,1.2,1.3,1,1.5,1.2,1.3,1,1.2,1.5,1.2,1.3,1,1.5,1.2,1,1.3,1.2,1.2,1,1.2],er:[{q:"Q1-25",a:2.6,e:2.5,rx:1}],dh:[{y:"24",a:1.2},{y:"23",a:1.15}],moat:"علامة رائدة في الألبان",risk:"تكاليف خام"},
"2060":{n:"التصنيع",en:"Tasnee",s:"المواد",p:15.80,ch:1.41,v:3.5,mc:9.4,pe:12.5,pb:1.1,dy:3.8,roe:9.5,de:.48,bt:1.1,eps:1.26,fcf:.8,ds:60,sc:62,rsi:56,m50:15.5,m200:15,sp:15,rs:16.5,tr:"عرضي",nm:9,ng:5,dg:2,pr:[15.2,15.3,15.5,15.3,15.6,15.4,15.7,15.5,15.8,15.6,15.9,15.7,15.8,15.6,15.7,15.9,15.7,15.8,15.6,15.8,15.7,15.9,15.8,15.8],vl:[3.5,4,3,4.5,3.5,4,3,4.5,3.5,4,3,3.5,4.5,3.5,4,3,4.5,3.5,3,4,3.5,3.5,3,3.5],er:[{q:"Q1-25",a:1.3,e:1.25,rx:.8}],dh:[{y:"24",a:.6},{y:"23",a:.55}],moat:"تنوع صناعي",risk:"ديون"},
"8010":{n:"التعاونية",en:"Tawuniya",s:"التأمين",p:165.00,ch:2.1,v:.35,mc:16.5,pe:18.5,pb:5.2,dy:2.5,roe:30.1,de:.15,bt:.75,eps:8.92,fcf:2,ds:80,sc:73,rsi:60,m50:162,m200:155,sp:158,rs:170,tr:"صاعد",nm:12,ng:15,dg:5,pr:[158,159,160,161,160,162,163,162,164,163,165,164,166,165,164,163,165,164,166,165,164,165,164,165],vl:[.3,.4,.3,.5,.3,.4,.3,.5,.3,.4,.3,.3,.5,.3,.4,.3,.5,.3,.3,.4,.3,.3,.3,.35],er:[{q:"Q1-25",a:9.2,e:8.8,rx:1.5}],dh:[{y:"24",a:4.1},{y:"23",a:3.8}],moat:"أكبر شركة تأمين سعودية",risk:"تنظيمات"},
"2150":{n:"زين السعودية",en:"Zain KSA",s:"الاتصالات",p:12.80,ch:.78,v:5.5,mc:7.7,pe:25.6,pb:1.8,dy:1.5,roe:7.2,de:.65,bt:.95,eps:.5,fcf:.3,ds:45,sc:48,rsi:55,m50:12.5,m200:12,sp:12,rs:13.5,tr:"عرضي",nm:8,ng:20,dg:0,pr:[12.2,12.3,12.4,12.3,12.5,12.4,12.6,12.5,12.7,12.6,12.8,12.7,12.9,12.8,12.7,12.6,12.8,12.7,12.9,12.8,12.7,12.8,12.8,12.8],vl:[5.5,6,5,7,5.5,6,5,7,5.5,6,5,5.5,7,5.5,6,5,7,5.5,5,6,5.5,5.5,5,5.5],er:[{q:"Q1-25",a:.55,e:.48,rx:2}],dh:[{y:"24",a:.19},{y:"23",a:.15}],moat:"شبكة 5G",risk:"ديون مرتفعة"},
"3010":{n:"أسمنت العربية",en:"Arabian Cement",s:"الأسمنت",p:42.50,ch:.47,v:.8,mc:5.1,pe:14.8,pb:1.5,dy:5.2,roe:10.5,de:.2,bt:.6,eps:2.87,fcf:1.2,ds:88,sc:71,rsi:50,m50:42,m200:41,sp:41,rs:44,tr:"عرضي",nm:25,ng:5,dg:3,pr:[41.5,41.8,42,41.7,42.2,42,42.4,42.2,42.5,42.3,42.6,42.4,42.7,42.5,42.3,42.1,42.4,42.3,42.5,42.3,42.5,42.3,42.4,42.5],vl:[.8,.9,.7,1,.8,.9,.7,1,.8,.9,.7,.8,1,.8,.9,.7,1,.8,.7,.9,.8,.8,.7,.8],er:[{q:"Q1-25",a:3,e:2.9,rx:.5}],dh:[{y:"24",a:2.2},{y:"23",a:2.1}],moat:"موقع استراتيجي",risk:"منافسة"},
"4001":{n:"أسمنت الجنوبية",en:"Southern Cement",s:"الأسمنت",p:68.20,ch:-.29,v:.4,mc:5.5,pe:16.5,pb:2.1,dy:4.5,roe:12.8,de:.1,bt:.5,eps:4.13,fcf:1.5,ds:90,sc:74,rsi:48,m50:68,m200:66,sp:66,rs:70,tr:"عرضي",nm:30,ng:3,dg:4,pr:[67,67.3,67.5,67.2,67.8,67.5,68,67.8,68.2,68,68.3,68.1,68.5,68.3,68,67.8,68.2,68,68.3,68.1,68.2,68,68.1,68.2],vl:[.4,.5,.3,.5,.4,.5,.3,.5,.4,.5,.3,.4,.5,.4,.5,.3,.5,.4,.3,.5,.4,.4,.3,.4],er:[{q:"Q1-25",a:4.2,e:4.1,rx:.3}],dh:[{y:"24",a:3.07},{y:"23",a:2.95}],moat:"هوامش ربح عالية",risk:"ركود بناء"},
"4260":{n:"بدجت",en:"Budget",s:"النقل",p:38.90,ch:1.83,v:1.2,mc:4.7,pe:11.5,pb:3.2,dy:5.8,roe:28.5,de:.35,bt:.8,eps:3.38,fcf:1.5,ds:82,sc:79,rsi:62,m50:38,m200:36.5,sp:37,rs:40,tr:"صاعد",nm:20,ng:15,dg:8,pr:[37,37.3,37.5,37.2,37.8,37.5,38,37.8,38.2,38,38.4,38.2,38.6,38.4,38.8,38.5,38.7,38.4,38.6,38.8,38.5,38.8,38.7,38.9],vl:[1.2,1.4,1,1.5,1.2,1.3,1,1.5,1.2,1.3,1,1.2,1.5,1.2,1.3,1,1.5,1.2,1,1.3,1.2,1.2,1,1.2],er:[{q:"Q1-25",a:3.5,e:3.3,rx:2}],dh:[{y:"24",a:2.26},{y:"23",a:2.1}],moat:"حصة سوقية في تأجير السيارات",risk:"منافسة"},
"4002":{n:"المتقدمة",en:"APPC",s:"المواد",p:52.10,ch:.58,v:.9,mc:5.2,pe:13.8,pb:2.5,dy:3.5,roe:18.5,de:.2,bt:.85,eps:3.78,fcf:1.8,ds:78,sc:72,rsi:57,m50:51.5,m200:50,sp:50,rs:54,tr:"صاعد",nm:18,ng:10,dg:5,pr:[50.5,50.8,51,50.7,51.3,51,51.5,51.3,51.8,51.5,52,51.8,52.2,52,51.8,51.5,52,51.8,52.1,51.9,52.1,51.9,52,52.1],vl:[.9,1,.8,1.1,.9,1,.8,1.1,.9,1,.8,.9,1.1,.9,1,.8,1.1,.9,.8,1,.9,.9,.8,.9],er:[{q:"Q1-25",a:3.9,e:3.7,rx:1}],dh:[{y:"24",a:1.82},{y:"23",a:1.7}],moat:"تقنية بتروكيماوية",risk:"دورة أسعار"},
"4321":{n:"الأندلس",en:"Andalus",s:"العقار",p:22.80,ch:-.88,v:1.5,mc:2.3,pe:19.5,pb:1.2,dy:2.8,roe:6.5,de:.45,bt:.9,eps:1.17,fcf:.3,ds:55,sc:50,rsi:44,m50:23.2,m200:23.8,sp:22,rs:24,tr:"هابط",nm:12,ng:-5,dg:0,pr:[23.5,23.3,23.4,23.2,23.3,23.1,23.2,23,23.1,22.9,23,22.8,23,22.9,22.7,22.8,23,22.8,22.9,22.7,22.8,22.9,22.8,22.8],vl:[1.5,1.7,1.3,1.8,1.5,1.7,1.3,1.8,1.5,1.7,1.3,1.5,1.8,1.5,1.7,1.3,1.8,1.5,1.3,1.7,1.5,1.5,1.3,1.5],er:[{q:"Q1-25",a:1.1,e:1.2,rx:-1.5}],dh:[{y:"24",a:.64},{y:"23",a:.65}],moat:"مراكز تجارية",risk:"ركود عقاري"},
"1150":{n:"البنك الأول",en:"SAB",s:"البنوك",p:42.35,ch:.83,v:2.1,mc:63.5,pe:13.5,pb:1.7,dy:3.5,roe:13.2,de:0,bt:.88,eps:3.14,fcf:7.5,ds:84,sc:73,rsi:56,m50:42,m200:41,sp:41,rs:44,tr:"صاعد",nm:48,ng:8,dg:6,pr:[41,41.2,41.5,41.3,41.6,41.4,41.8,41.6,42,41.8,42.2,42,42.3,42.1,42,41.8,42.1,42,42.3,42.1,42.3,42.1,42.2,42.35],vl:[2,2.3,1.8,2.5,2,2.3,1.8,2.5,2,2.3,1.8,2,2.5,2,2.3,1.8,2.5,2,1.8,2.3,2,2,1.8,2.1],er:[{q:"Q1-25",a:3.3,e:3.2,rx:.8}],dh:[{y:"24",a:1.48},{y:"23",a:1.4}],moat:"تكامل مع HSBC",risk:"فائدة"},
};

const PERF=Array.from({length:24},(_,i)=>({d:i+1,pf:100+Math.sin(i/3)*3+i*.8+(Math.random()-.3)*1.5,tasi:100+Math.sin(i/4)*2+i*.5+(Math.random()-.3)*1}));
const SP=[{n:"البنوك",pf:3.2,m:8.5},{n:"الطاقة",pf:1.8,m:5.2},{n:"الاتصالات",pf:1.5,m:4.8},{n:"النقل",pf:2.8,m:7.1},{n:"التجزئة",pf:1.2,m:6.2},{n:"المواد",pf:-1.5,m:-5.3},{n:"الأغذية",pf:.9,m:3.5},{n:"التأمين",pf:.5,m:1.8},{n:"الأسمنت",pf:.3,m:2.1},{n:"العقار",pf:-.8,m:-2.1}];

// Market breadth
const adv=Object.values(S).filter(x=>x.ch>0).length;
const dec=Object.values(S).filter(x=>x.ch<0).length;
const unch=Object.values(S).filter(x=>x.ch===0).length;
const totalStocks=Object.keys(S).length;

const K={nv:"#0f1729",gd:"#d4a84b",bl:"#3b82f6",gn:"#10b981",rd:"#ef4444",tx:"#e2e8f0",dm:"#94a3b8",mt:"#64748b",cd:"#1e293b",ch:"#263348",bd:"#334155",bg:"#0b1120",pu:"#8b5cf6",or:"#f59e0b"};
const PC=["#3b82f6","#10b981","#d4a84b","#ef4444","#8b5cf6","#06b6d4","#f59e0b","#ec4899"];

const Bd=({ch,cl="bl"})=>{const m={gn:K.gn,rd:K.rd,gd:K.gd,bl:K.bl,pu:K.pu,or:K.or};return<span style={{background:`${(m[cl]||K.bl)}20`,color:m[cl]||K.bl,padding:"2px 7px",borderRadius:14,fontSize:9,fontWeight:600,whiteSpace:"nowrap"}}>{ch}</span>};
const Cd=({children,style:st,...p})=><div style={{background:K.cd,borderRadius:9,border:`1px solid ${K.bd}`,overflow:"hidden",...st}} {...p}>{children}</div>;
const Mt=({l,val,sub,ic:I,tr,sm})=>(<Cd style={{padding:sm?"8px 10px":"11px 13px",flex:1,minWidth:sm?100:120}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:sm?2:4}}><span style={{color:K.dm,fontSize:sm?8:10}}>{l}</span>{I&&<I size={sm?10:12} color={K.mt}/>}</div><div style={{fontSize:sm?14:17,fontWeight:700}}>{val}</div>{sub&&<div style={{fontSize:sm?8:9,marginTop:1,color:tr==="u"?K.gn:tr==="d"?K.rd:K.dm}}>{sub}</div>}</Cd>);
const Bt=({ch,act,onClick,cl=K.gd,sm,dis})=>(<button onClick={onClick} disabled={dis} style={{padding:sm?"3px 6px":"5px 11px",borderRadius:6,border:`1px solid ${act?cl:K.bd}`,background:act?`${cl}18`:"transparent",color:act?cl:K.dm,cursor:dis?"not-allowed":"pointer",fontSize:sm?9:10,fontWeight:600,opacity:dis?.4:1,whiteSpace:"nowrap"}}>{ch}</button>);
const SB=({v})=>(<div style={{display:"flex",alignItems:"center",gap:3}}><div style={{width:36,height:4,background:K.nv,borderRadius:2,overflow:"hidden"}}><div style={{width:`${v}%`,height:"100%",background:v>70?K.gn:v>50?K.gd:K.rd,borderRadius:2}}/></div><span style={{fontWeight:700,fontSize:9,color:v>70?K.gn:v>50?K.gd:K.rd}}>{v}</span></div>);

export default function App(){
  const[pg,setPg]=useState("dashboard");
  const[sel,setSel]=useState("2222");
  const[sr,setSr]=useState("");
  const[so,setSo]=useState(true);
  const[aiL,setAiL]=useState(false);const[aiR,setAiR]=useState("");
  const[fl,setFl]=useState(null);
  const[tb,setTb]=useState("أساسي");
  const[vm,setVm]=useState("مستثمر");
  const[cs,setCs]=useState("1120");
  const[pf,setPf]=useState([{c:"2222",q:500,a:27.5},{c:"1120",q:100,a:90},{c:"7010",q:300,a:42},{c:"4030",q:200,a:33},{c:"4190",q:50,a:145},{c:"1010",q:400,a:27},{c:"2280",q:150,a:51}]);
  const[wl,setWl]=useState(["2222","1120","1180","7010","4030","4190","4200","2280","4260","8010"]);
  const[chatMsgs,setChatMsgs]=useState([]);
  const[chatInput,setChatInput]=useState("");
  const[chatLoading,setChatLoading]=useState(false);
  const chatRef=useRef(null);

  const st=S[sel];
  const go=useCallback((c)=>{setSel(c);setPg("stock");setTb("أساسي");setAiR("")},[]);

  // AI helper
  const callAI=async(sys,msg)=>{
    try{const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,system:sys,messages:[{role:"user",content:msg}]})});
    const d=await r.json();return d.content?.map(c=>c.text||"").join("\n")||"خطأ"}catch{return"حدث خطأ"}};

  const runAI=async(pr)=>{setAiL(true);setAiR("");const d=S[sel];setAiR(await callAI("محلل مالي سعودي. عربي مختصر. بدون markdown.",`${pr}\n\n${d.n}(${sel})|${d.p}|${d.ch}%|PE:${d.pe}|DY:${d.dy}%|ROE:${d.roe}%|Beta:${d.bt}|RSI:${d.rsi}|${d.tr}|Score:${d.sc}/100|DS:${d.ds}|NM:${d.nm}%|NG:${d.ng}%|FCF:${d.fcf}B|Moat:${d.moat}`));setAiL(false)};

  // AI Chat
  const sendChat=async()=>{
    if(!chatInput.trim()||chatLoading)return;
    const msg=chatInput;setChatInput("");
    setChatMsgs(p=>[...p,{role:"user",text:msg}]);setChatLoading(true);
    const allStocks=Object.entries(S).map(([c,s])=>`${s.n}(${c}):${s.p}ر.س,${s.ch}%,PE${s.pe},DY${s.dy}%,ROE${s.roe}%,Score${s.sc},${s.tr}`).join("|");
    const reply=await callAI("أنت مساعد تحليل أسهم سعودي ذكي اسمك 'بصيرة'. تجيب بالعربية بشكل مختصر ومفيد. لديك بيانات كل الأسهم السعودية. بدون markdown. كن عملياً واقترح إجراءات واضحة.",`${msg}\n\nبيانات السوق:\n${allStocks}`);
    setChatMsgs(p=>[...p,{role:"ai",text:reply}]);setChatLoading(false);
  };

  useEffect(()=>{chatRef.current?.scrollTo(0,chatRef.current.scrollHeight)},[chatMsgs]);

  // Portfolio
  const pfD=useMemo(()=>{let tv=0,tc=0;const items=pf.map(p=>{const s=S[p.c];if(!s)return null;const v=s.p*p.q,c=p.a*p.q;tv+=v;tc+=c;return{...p,nm:s.n,sec:s.s,cp:s.p,v,c,pnl:v-c,pnlP:((v/c)-1)*100,w:0,sc:s.sc,dy:s.dy}}).filter(Boolean);items.forEach(i=>i.w=i.v/tv*100);const sec={};items.forEach(i=>{sec[i.sec]=(sec[i.sec]||0)+i.v});return{items,tv,tc,pnl:tv-tc,pnlP:((tv/tc)-1)*100,secs:Object.entries(sec).map(([n,v])=>({name:n,value:+(v/tv*100).toFixed(1)})),annDiv:items.reduce((a,i)=>{const s=S[i.c];return a+(s?s.dy/100*i.v:0)},0)}},[pf]);

  const scr=useMemo(()=>{let r=Object.entries(S).map(([c,s])=>({c,...s}));if(fl==="value")r.sort((a,b)=>a.pe-b.pe);else if(fl==="quality")r.sort((a,b)=>b.roe-a.roe);else if(fl==="growth")r.sort((a,b)=>b.ng-a.ng);else if(fl==="dividend")r.sort((a,b)=>b.dy-a.dy);else if(fl==="momentum")r.sort((a,b)=>b.ch-a.ch);else if(fl==="lowrisk")r.sort((a,b)=>a.bt-b.bt);else if(fl==="buffett")r.sort((a,b)=>(b.roe-b.pe+b.ds/10)-(a.roe-a.pe+a.ds/10));else r.sort((a,b)=>b.sc-a.sc);return r},[fl]);

  const filt=useMemo(()=>sr?Object.entries(S).filter(([c,s])=>s.n.includes(sr)||s.en.toLowerCase().includes(sr.toLowerCase())||c.includes(sr)):[], [sr]);
  const toggleWl=(c)=>wl.includes(c)?setWl(wl.filter(x=>x!==c)):setWl([...wl,c]);

  const nav=[{id:"dashboard",l:"القيادة",ic:Home},{id:"stock",l:"السهم",ic:Activity},{id:"market",l:"نظرة السوق",ic:Globe},{id:"screener",l:"الفلاتر",ic:Filter},{id:"portfolio",l:"المحفظة",ic:Briefcase},{id:"compare",l:"المقارنة",ic:GitCompare},{id:"sectors",l:"القطاعات",ic:Layers},{id:"chat",l:"محادثة AI",ic:MessageCircle},{id:"reports",l:"التقارير",ic:FileText},{id:"checklist",l:"تشيك ليست",ic:CheckCircle},{id:"alerts",l:"التنبيهات",ic:Bell},{id:"settings",l:"الإعدادات",ic:Settings}];

  // Checklist
  const cl=useMemo(()=>st?[{q:"P/E معقول؟",a:`${st.pe}`,p:st.pe<20},{q:"ROE جيد؟",a:`${st.roe}%`,p:st.roe>12},{q:"ديون محكومة؟",a:`${st.de}`,p:st.de<.5},{q:"نمو أرباح؟",a:`${st.ng}%`,p:st.ng>0},{q:"توزيعات آمنة؟",a:`${st.ds}/100`,p:st.ds>60},{q:"عائد مجزي؟",a:`${st.dy}%`,p:st.dy>2.5},{q:"اتجاه إيجابي؟",a:st.tr,p:st.tr==="صاعد"},{q:"فوق MA200؟",a:`${st.p}>${st.m200}`,p:st.p>st.m200},{q:"FCF إيجابي؟",a:`${st.fcf}B`,p:st.fcf>0},{q:"بيتا مناسب؟",a:`${st.bt}`,p:st.bt<1.2},{q:"درجة مركبة جيدة؟",a:`${st.sc}`,p:st.sc>55}]:[], [st]);
  const passN=cl.filter(c=>c.p).length;

  return(
  <div dir="rtl" style={{display:"flex",height:"100vh",fontFamily:"'Segoe UI',Tahoma,sans-serif",background:K.bg,color:K.tx,overflow:"hidden",fontSize:11}}>
    <div style={{width:so?180:48,background:K.nv,borderLeft:`1px solid ${K.bd}`,transition:"width .2s",display:"flex",flexDirection:"column",flexShrink:0,overflow:"hidden"}}>
      <div style={{padding:so?"9px 10px":"9px 4px",borderBottom:`1px solid ${K.bd}`,display:"flex",alignItems:"center",gap:4,justifyContent:so?"space-between":"center",minHeight:42}}>
        {so&&<div><div style={{fontSize:13,fontWeight:800,color:K.gd}}>تداول بصيرة</div><div style={{fontSize:7,color:K.mt}}>v5.0 | {totalStocks} سهم</div></div>}
        <button onClick={()=>setSo(!so)} style={{background:"none",border:"none",color:K.dm,cursor:"pointer"}}>{so?<ChevronRight size={13}/>:<ChevronLeft size={13}/>}</button>
      </div>
      <div style={{flex:1,paddingTop:2,overflowY:"auto"}}>{nav.map(n=>(
        <div key={n.id} onClick={()=>setPg(n.id)} style={{display:"flex",alignItems:"center",gap:6,padding:so?"5px 9px":"5px 0",margin:"1px 3px",borderRadius:5,cursor:"pointer",background:pg===n.id?`${K.gd}15`:"transparent",color:pg===n.id?K.gd:K.dm,justifyContent:so?"flex-start":"center"}} onMouseEnter={e=>{if(pg!==n.id)e.currentTarget.style.background=K.ch}} onMouseLeave={e=>{if(pg!==n.id)e.currentTarget.style.background="transparent"}}>
          <n.ic size={13}/>{so&&<span style={{fontSize:10,fontWeight:pg===n.id?600:400}}>{n.l}</span>}
        </div>))}</div>
      {so&&<div style={{padding:"4px 6px",borderTop:`1px solid ${K.bd}`,display:"flex",gap:2,justifyContent:"center"}}>{["مستثمر","مضارب","مدير"].map(m=><Bt key={m} sm ch={m} act={vm===m} onClick={()=>setVm(m)}/>)}</div>}
    </div>

    <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
      <div style={{background:K.nv,borderBottom:`1px solid ${K.bd}`,padding:"5px 12px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:8,flexShrink:0}}>
        <div style={{position:"relative",flex:1,maxWidth:280}}>
          <Search size={12} style={{position:"absolute",right:7,top:6,color:K.mt}}/>
          <input value={sr} onChange={e=>setSr(e.target.value)} placeholder={`ابحث في ${totalStocks} سهم...`} style={{width:"100%",background:K.cd,border:`1px solid ${K.bd}`,borderRadius:6,padding:"5px 24px 5px 7px",color:K.tx,fontSize:10,outline:"none"}}/>
          {sr&&<div style={{position:"absolute",top:28,right:0,left:0,background:K.cd,border:`1px solid ${K.bd}`,borderRadius:6,zIndex:100,maxHeight:180,overflowY:"auto",boxShadow:"0 6px 20px rgba(0,0,0,.5)"}}>{filt.map(([c,s])=><div key={c} onClick={()=>{go(c);setSr("")}} style={{display:"flex",justifyContent:"space-between",padding:"6px 8px",cursor:"pointer",borderBottom:`1px solid ${K.bd}`,fontSize:10}} onMouseEnter={e=>e.currentTarget.style.background=K.ch} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><strong>{s.n}</strong><span style={{color:s.ch>=0?K.gn:K.rd}}>{s.p} ({s.ch>=0?"+":""}{s.ch}%)</span></div>)}</div>}
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10,fontSize:9}}>
          <span style={{color:K.gn,fontWeight:700}}>تاسي 12,245 +0.85%</span>
          <span style={{color:K.dm}}>|</span>
          <span style={{color:K.gn}}>{adv}↑</span><span style={{color:K.rd}}>{dec}↓</span>
          <Bd ch={vm} cl="gd"/>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:"10px 14px"}}>

{/* ══ DASHBOARD ══ */}
{pg==="dashboard"&&<div>
  <div style={{display:"flex",gap:6,marginBottom:8,flexWrap:"wrap"}}>
    <Mt l="المحفظة" val={`${(pfD.tv/1e3).toFixed(1)}K`} sub={`${pfD.pnlP>=0?"+":""}${pfD.pnlP.toFixed(1)}%`} tr={pfD.pnlP>=0?"u":"d"} ic={Briefcase}/>
    <Mt l="الربح" val={`${pfD.pnl>=0?"+":""}${pfD.pnl.toFixed(0)}`} tr={pfD.pnl>=0?"u":"d"}/>
    <Mt l="دخل توزيعات" val={`${pfD.annDiv.toFixed(0)}/سنة`} ic={DollarSign}/>
    <Mt l="مرتفعة/منخفضة" val={`${adv}/${dec}`} sub={`من ${totalStocks}`} ic={TrendingUp}/>
    <Mt l="أفضل اليوم" val="البحري +2.62%" ic={Award} tr="u"/>
  </div>
  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
    <Cd style={{padding:9}}><div style={{fontSize:10,fontWeight:600,marginBottom:5}}>أداء المحفظة vs تاسي</div><ResponsiveContainer width="100%" height={140}><LineChart data={PERF}><CartesianGrid strokeDasharray="3 3" stroke={K.bd} opacity={.3}/><XAxis dataKey="d" tick={{fill:K.mt,fontSize:7}} axisLine={false}/><YAxis tick={{fill:K.mt,fontSize:7}} axisLine={false} domain={["auto","auto"]}/><Tooltip contentStyle={{background:K.nv,border:`1px solid ${K.bd}`,borderRadius:5,fontSize:8}}/><Legend wrapperStyle={{fontSize:8}}/><Line type="monotone" dataKey="pf" name="محفظتي" stroke={K.gd} strokeWidth={2} dot={false}/><Line type="monotone" dataKey="tasi" name="تاسي" stroke={K.bl} strokeWidth={1.5} dot={false} strokeDasharray="4 2"/></LineChart></ResponsiveContainer></Cd>
    <Cd style={{padding:9}}><div style={{fontSize:10,fontWeight:600,marginBottom:5}}>القطاعات</div><div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:3}}>{SP.map(sec=><div key={sec.n} onClick={()=>setPg("sectors")} style={{background:sec.pf>=0?`${K.gn}10`:`${K.rd}10`,borderRadius:4,padding:"5px 2px",textAlign:"center",cursor:"pointer"}}><div style={{fontSize:7,color:K.dm}}>{sec.n}</div><div style={{fontSize:11,fontWeight:700,color:sec.pf>=0?K.gn:K.rd}}>{sec.pf>=0?"+":""}{sec.pf}%</div></div>)}</div></Cd>
  </div>
  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
    <Cd><div style={{padding:"6px 9px",borderBottom:`1px solid ${K.bd}`,fontWeight:600,fontSize:10}}>المراقبة ({wl.length})</div><div style={{maxHeight:200,overflowY:"auto"}}>{wl.map(c=>S[c]&&<div key={c} onClick={()=>go(c)} style={{display:"flex",justifyContent:"space-between",padding:"5px 9px",borderBottom:`1px solid ${K.bd}`,cursor:"pointer",fontSize:10}} onMouseEnter={e=>e.currentTarget.style.background=K.ch} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><strong>{S[c].n}</strong><div style={{display:"flex",gap:5}}><span style={{color:S[c].ch>=0?K.gn:K.rd}}>{S[c].ch>=0?"+":""}{S[c].ch}%</span><SB v={S[c].sc}/></div></div>)}</div></Cd>
    <Cd style={{padding:9,background:`linear-gradient(135deg,${K.nv},${K.cd})`,border:`1px solid ${K.gd}20`}}>
      <div style={{display:"flex",alignItems:"center",gap:3,marginBottom:5}}><Brain size={12} color={K.gd}/><span style={{fontSize:10,fontWeight:600,color:K.gd}}>ملخص AI</span></div>
      <div style={{fontSize:10,lineHeight:1.8,color:K.dm}}>السوق إيجابي بدعم البنوك (+3.2%) والنقل (+2.8%). البحري الأفضل +2.62%. سابك وكيان تحت الضغط. التعاونية تواصل الصعود +2.1%. بدجت يرتفع +1.83% بزخم قوي. ترقبوا نتائج أرامكو قريباً.</div>
      <div style={{display:"flex",gap:3,marginTop:5,flexWrap:"wrap"}}><Bd ch="السوق إيجابي" cl="gn"/><Bd ch="موسم نتائج" cl="gd"/><Bd ch={`${adv} سهم مرتفع`} cl="bl"/></div>
    </Cd>
  </div>
</div>}

{/* ══ MARKET OVERVIEW ══ */}
{pg==="market"&&<div>
  <h2 style={{fontSize:16,fontWeight:700,color:K.gd,margin:"0 0 10px"}}>نظرة عامة على السوق</h2>
  <div style={{display:"flex",gap:6,marginBottom:10,flexWrap:"wrap"}}>
    <Mt l="مؤشر تاسي" val="12,245" sub="+0.85%" tr="u" ic={TrendingUp}/>
    <Mt l="مرتفعة" val={adv} sub={`${(adv/totalStocks*100).toFixed(0)}%`} tr="u" ic={TrendingUp}/>
    <Mt l="منخفضة" val={dec} sub={`${(dec/totalStocks*100).toFixed(0)}%`} tr="d" ic={TrendingDown}/>
    <Mt l="إجمالي الأسهم" val={totalStocks} ic={BarChart3}/>
    <Mt l="متوسط P/E" val={(Object.values(S).reduce((a,s)=>a+s.pe,0)/totalStocks).toFixed(1)}/>
  </div>
  {/* Market breadth bar */}
  <Cd style={{padding:12,marginBottom:10}}>
    <div style={{fontSize:11,fontWeight:600,marginBottom:6}}>عمق السوق</div>
    <div style={{display:"flex",height:24,borderRadius:6,overflow:"hidden",marginBottom:6}}>
      <div style={{width:`${adv/totalStocks*100}%`,background:K.gn,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700}}>{adv}</div>
      <div style={{width:`${dec/totalStocks*100}%`,background:K.rd,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700}}>{dec}</div>
    </div>
    <div style={{display:"flex",justifyContent:"space-between",fontSize:9,color:K.dm}}><span>مرتفعة: {adv}</span><span>منخفضة: {dec}</span></div>
  </Cd>
  {/* Top gainers & losers */}
  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:10}}>
    <Cd><div style={{padding:"6px 9px",borderBottom:`1px solid ${K.bd}`,fontWeight:600,fontSize:10,color:K.gn}}>أكثر ارتفاعاً</div>{Object.entries(S).sort(([,a],[,b])=>b.ch-a.ch).slice(0,7).map(([c,s])=><div key={c} onClick={()=>go(c)} style={{display:"flex",justifyContent:"space-between",padding:"5px 9px",borderBottom:`1px solid ${K.bd}`,cursor:"pointer",fontSize:10}} onMouseEnter={e=>e.currentTarget.style.background=K.ch} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><strong>{s.n}</strong><span style={{color:K.gn,fontWeight:600}}>+{s.ch}%</span></div>)}</Cd>
    <Cd><div style={{padding:"6px 9px",borderBottom:`1px solid ${K.bd}`,fontWeight:600,fontSize:10,color:K.rd}}>أكثر انخفاضاً</div>{Object.entries(S).sort(([,a],[,b])=>a.ch-b.ch).slice(0,7).map(([c,s])=><div key={c} onClick={()=>go(c)} style={{display:"flex",justifyContent:"space-between",padding:"5px 9px",borderBottom:`1px solid ${K.bd}`,cursor:"pointer",fontSize:10}} onMouseEnter={e=>e.currentTarget.style.background=K.ch} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><strong>{s.n}</strong><span style={{color:K.rd,fontWeight:600}}>{s.ch}%</span></div>)}</Cd>
  </div>
  {/* Volume leaders */}
  <Cd><div style={{padding:"6px 9px",borderBottom:`1px solid ${K.bd}`,fontWeight:600,fontSize:10}}>الأنشط تداولاً (بالمليون)</div>{Object.entries(S).sort(([,a],[,b])=>b.v-a.v).slice(0,8).map(([c,s])=><div key={c} onClick={()=>go(c)} style={{display:"flex",justifyContent:"space-between",padding:"5px 9px",borderBottom:`1px solid ${K.bd}`,cursor:"pointer",fontSize:10}} onMouseEnter={e=>e.currentTarget.style.background=K.ch} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><strong>{s.n}</strong><div style={{display:"flex",gap:6}}><span>{s.v}M</span><span style={{color:s.ch>=0?K.gn:K.rd}}>{s.ch>=0?"+":""}{s.ch}%</span></div></div>)}</Cd>
</div>}

{/* ══ STOCK ══ */}
{pg==="stock"&&st&&<div>
  <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
    <div><div style={{display:"flex",alignItems:"center",gap:4,marginBottom:1}}><h2 style={{fontSize:17,fontWeight:700,margin:0}}>{st.n}</h2><Bd ch={st.s} cl="gd"/><Bd ch={st.tr} cl={st.tr==="صاعد"?"gn":st.tr==="هابط"?"rd":"or"}/><button onClick={()=>toggleWl(sel)} style={{background:"none",border:"none",cursor:"pointer"}}><Star size={13} fill={wl.includes(sel)?K.gd:"none"} color={K.gd}/></button></div><span style={{color:K.mt,fontSize:9}}>{sel} · {st.en} · {st.mc}B</span></div>
    <div style={{textAlign:"left"}}><div style={{fontSize:22,fontWeight:800}}>{st.p.toFixed(2)}</div><div style={{fontSize:12,color:st.ch>=0?K.gn:K.rd}}>{st.ch>=0?"+":""}{st.ch}%</div></div>
  </div>
  <div style={{display:"flex",gap:4,marginBottom:6,flexWrap:"wrap"}}><Mt sm l="P/E" val={st.pe}/><Mt sm l="عائد" val={`${st.dy}%`}/><Mt sm l="ROE" val={`${st.roe}%`}/><Mt sm l="بيتا" val={st.bt}/><Mt sm l="درجة" val={`${st.sc}`}/></div>
  {/* Price + Volume Chart */}
  <Cd style={{padding:9,marginBottom:8}}>
    <ResponsiveContainer width="100%" height={200}><ComposedChart data={st.pr.map((p,i)=>({d:i+1,p,vol:st.vl[i]}))}><defs><linearGradient id="sg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={st.ch>=0?K.gn:K.rd} stopOpacity={.1}/><stop offset="100%" stopColor={st.ch>=0?K.gn:K.rd} stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" stroke={K.bd} opacity={.3}/><XAxis dataKey="d" tick={{fill:K.mt,fontSize:7}} axisLine={false}/><YAxis yAxisId="price" tick={{fill:K.mt,fontSize:7}} axisLine={false} domain={["auto","auto"]}/><YAxis yAxisId="vol" orientation="left" tick={{fill:K.mt,fontSize:7}} axisLine={false} domain={[0,"auto"]}/><Tooltip contentStyle={{background:K.nv,border:`1px solid ${K.bd}`,borderRadius:5,fontSize:8}}/><Bar yAxisId="vol" dataKey="vol" fill={`${K.bl}30`} radius={[2,2,0,0]}/><Area yAxisId="price" type="monotone" dataKey="p" fill="url(#sg)" stroke="none"/><Line yAxisId="price" type="monotone" dataKey="p" stroke={st.ch>=0?K.gn:K.rd} strokeWidth={2} dot={false}/></ComposedChart></ResponsiveContainer>
  </Cd>
  <div style={{display:"flex",gap:2,background:K.nv,borderRadius:6,padding:2,marginBottom:8,overflowX:"auto"}}>{(vm==="مضارب"?["فني","أساسي","أرباح","AI"]:["أساسي","فني","أرباح","توزيعات","مخاطر","AI"]).map(t=><button key={t} onClick={()=>setTb(t)} style={{flex:1,padding:"4px 5px",borderRadius:4,border:"none",cursor:"pointer",fontSize:9,fontWeight:tb===t?600:400,background:tb===t?K.cd:"transparent",color:tb===t?K.gd:K.dm,whiteSpace:"nowrap"}}>{t}</button>)}</div>
  <Cd style={{padding:12}}>
    {tb==="أساسي"&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}><div><table style={{width:"100%",borderCollapse:"collapse",fontSize:10}}><tbody>{[["ROE",`${st.roe}%`],["EPS",st.eps],["P/E",st.pe],["P/B",st.pb],["هامش",`${st.nm}%`],["نمو أرباح",`${st.ng}%`],["FCF",`${st.fcf}B`],["ديون",st.de]].map(([l,v],i)=><tr key={i} style={{borderBottom:`1px solid ${K.bd}`}}><td style={{padding:"4px 0",color:K.dm}}>{l}</td><td style={{fontWeight:600,textAlign:"left"}}>{v}</td></tr>)}</tbody></table></div><div style={{padding:9,background:`${K.gd}08`,borderRadius:7}}><div style={{fontSize:10,fontWeight:600,color:K.gd,marginBottom:3}}>الخلاصة</div><div style={{fontSize:10,color:K.dm,lineHeight:1.7}}>{st.sc>75?"ممتاز":st.sc>60?"جيد":st.sc>45?"متوسط":"ضعيف"} | <strong>الخندق:</strong> {st.moat} | <strong>المخاطر:</strong> {st.risk}</div><div style={{marginTop:4}}><Bd ch={st.sc>70?"جذاب":st.sc>50?"محايد":"حذر"} cl={st.sc>70?"gn":st.sc>50?"gd":"rd"}/></div></div></div>}
    {tb==="فني"&&<div><div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:5,marginBottom:8}}>{[{l:"اتجاه",v:st.tr,c:st.tr==="صاعد"?K.gn:st.tr==="هابط"?K.rd:K.gd},{l:"RSI",v:st.rsi,c:st.rsi>70?K.rd:st.rsi<30?K.gn:K.gd},{l:"MACD",v:S[sel]?.macd||0,c:(S[sel]?.macd||0)>0?K.gn:K.rd},{l:"دعم",v:st.sp,c:K.bl},{l:"مقاومة",v:st.rs,c:K.bl},{l:"MA50",v:st.m50,c:st.p>st.m50?K.gn:K.rd}].map((m,i)=><div key={i} style={{background:K.nv,borderRadius:5,padding:7,textAlign:"center"}}><div style={{fontSize:7,color:K.mt}}>{m.l}</div><div style={{fontSize:13,fontWeight:700,color:m.c}}>{m.v}</div></div>)}</div><div style={{padding:8,background:`${K.bl}08`,borderRadius:6,fontSize:10}}><strong style={{color:K.bl}}>خطة الصفقة:</strong> دخول {(st.sp+(st.p-st.sp)*.3).toFixed(2)} | وقف <span style={{color:K.rd}}>{(st.sp*.97).toFixed(2)}</span> | هدف <span style={{color:K.gn}}>{st.rs}</span> | R:R <span style={{color:K.gd}}>1:2.5</span></div></div>}
    {tb==="أرباح"&&<div><ResponsiveContainer width="100%" height={140}><BarChart data={st.er.slice().reverse()}><CartesianGrid strokeDasharray="3 3" stroke={K.bd} opacity={.3}/><XAxis dataKey="q" tick={{fill:K.mt,fontSize:8}} axisLine={false}/><YAxis tick={{fill:K.mt,fontSize:8}} axisLine={false}/><Tooltip contentStyle={{background:K.nv,border:`1px solid ${K.bd}`,borderRadius:5,fontSize:8}}/><Bar dataKey="a" name="فعلي" fill={K.bl} radius={[2,2,0,0]}/><Bar dataKey="e" name="متوقع" fill={`${K.gd}80`} radius={[2,2,0,0]}/></BarChart></ResponsiveContainer>{st.er.map((e,i)=>{const su=((e.a-e.e)/e.e*100).toFixed(1);return<div key={i} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:`1px solid ${K.bd}`,fontSize:10}}><span style={{fontWeight:600}}>{e.q}</span><div style={{display:"flex",gap:6}}><span>فعلي: {e.a}</span><Bd ch={`${su>0?"+":""}${su}%`} cl={su>0?"gn":"rd"}/><span style={{color:e.rx>0?K.gn:K.rd}}>ردة: {e.rx>0?"+":""}{e.rx}%</span></div></div>})}</div>}
    {tb==="توزيعات"&&<div><div style={{display:"flex",gap:4,marginBottom:8}}><Mt sm l="عائد" val={`${st.dy}%`}/><Mt sm l="أمان" val={`${st.ds}`}/><Mt sm l="نمو" val={`${st.dg}%`}/></div><ResponsiveContainer width="100%" height={120}><BarChart data={st.dh.slice().reverse()}><XAxis dataKey="y" tick={{fill:K.mt,fontSize:8}} axisLine={false}/><YAxis tick={{fill:K.mt,fontSize:8}} axisLine={false}/><Bar dataKey="a" fill={K.gn} radius={[2,2,0,0]}/></BarChart></ResponsiveContainer><div style={{marginTop:6,padding:8,background:`${K.gn}08`,borderRadius:6,display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:4,fontSize:10}}>{[1e5,5e5,1e6].map(a=><div key={a} style={{textAlign:"center"}}><div style={{color:K.mt,fontSize:8}}>{a/1e3}K</div><div style={{fontWeight:700,color:K.gn}}>{(a*st.dy/100).toFixed(0)}</div></div>)}</div></div>}
    {tb==="مخاطر"&&<div><table style={{width:"100%",borderCollapse:"collapse",fontSize:10}}><tbody>{[["بيتا",st.bt,st.bt>1?"rd":"gn"],["RSI",st.rsi,st.rsi>70?"rd":"gd"],["ديون",st.de,st.de>.5?"rd":"gn"],["أمان توزيعات",st.ds,st.ds>70?"gn":"rd"]].map(([l,v,cl],i)=><tr key={i} style={{borderBottom:`1px solid ${K.bd}`}}><td style={{padding:4,color:K.dm}}>{l}</td><td style={{fontWeight:600}}>{v}</td><td><Bd ch={cl==="gn"?"جيد":"حذر"} cl={cl}/></td></tr>)}</tbody></table><div style={{marginTop:6,padding:8,background:`${K.rd}08`,borderRadius:6,fontSize:10,lineHeight:1.8}}><strong style={{color:K.rd}}>ضغط:</strong> {[10,20,30].map(d=><span key={d}> -{d}%→<strong style={{color:K.rd}}>-{(d*st.bt).toFixed(1)}%</strong>({(st.p*(1-d*st.bt/100)).toFixed(2)}) </span>)}</div></div>}
    {tb==="AI"&&<div><div style={{display:"flex",gap:2,marginBottom:8,flexWrap:"wrap"}}>{[{l:"ملخص",p:"ملخص استثماري 6 نقاط"},{l:"مؤسسي",p:"تقرير: قوة، ضعف، توصية"},{l:"أهم 5",p:"أهم 5 نقاط قبل الشراء"},{l:"فني",p:"تحليل فني وخطة صفقة"}].map(b=><Bt key={b.l} ch={b.l} onClick={()=>runAI(b.p)} dis={aiL} sm/>)}</div>{aiL&&<div style={{color:K.gd,padding:12,textAlign:"center",fontSize:10}}><RefreshCw size={12} style={{animation:"sp 1s linear infinite"}}/> تحليل...<style>{`@keyframes sp{to{transform:rotate(360deg)}}`}</style></div>}{aiR&&!aiL&&<div style={{background:K.nv,borderRadius:6,padding:10,border:`1px solid ${K.gd}20`,whiteSpace:"pre-wrap",fontSize:10,lineHeight:1.8}}>{aiR}</div>}{!aiR&&!aiL&&<div style={{textAlign:"center",padding:20,color:K.mt,fontSize:10}}><Brain size={24} style={{opacity:.2}}/><div>اختر نوع التحليل</div></div>}</div>}
  </Cd>
</div>}

{/* ══ AI CHAT ══ */}
{pg==="chat"&&<div style={{display:"flex",flexDirection:"column",height:"calc(100vh - 100px)"}}>
  <div style={{display:"flex",alignItems:"center",gap:5,marginBottom:8}}><Brain size={18} color={K.gd}/><h2 style={{fontSize:16,fontWeight:700,color:K.gd,margin:0}}>محادثة بصيرة الذكية</h2></div>
  <Cd style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
    <div ref={chatRef} style={{flex:1,overflowY:"auto",padding:12}}>
      {chatMsgs.length===0&&<div style={{textAlign:"center",padding:30,color:K.mt}}>
        <Brain size={40} style={{opacity:.15,marginBottom:8}}/>
        <div style={{fontSize:12,marginBottom:12}}>مرحباً! أنا بصيرة، مساعدك الذكي لتحليل الأسهم السعودية.</div>
        <div style={{fontSize:10,color:K.dm,marginBottom:12}}>اسألني أي شيء عن {totalStocks} سهم سعودي. أمثلة:</div>
        <div style={{display:"flex",gap:4,flexWrap:"wrap",justifyContent:"center"}}>
          {["ما أفضل أسهم التوزيعات؟","حلل لي أرامكو","قارن الراجحي والأهلي","ما الأسهم الأقل مخاطرة؟","ما أفضل سهم للشراء الآن؟","اقترح محفظة متوازنة"].map(q=><button key={q} onClick={()=>{setChatInput(q);}} style={{background:`${K.gd}10`,border:`1px solid ${K.gd}25`,borderRadius:6,padding:"5px 10px",color:K.gd,cursor:"pointer",fontSize:9}}>{q}</button>)}
        </div>
      </div>}
      {chatMsgs.map((m,i)=><div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-start":"flex-end",marginBottom:8}}>
        <div style={{maxWidth:"80%",padding:"8px 12px",borderRadius:m.role==="user"?"12px 12px 4px 12px":"12px 12px 12px 4px",background:m.role==="user"?K.bl:`${K.gd}15`,color:m.role==="user"?"white":K.tx,fontSize:11,lineHeight:1.7,whiteSpace:"pre-wrap",border:m.role==="ai"?`1px solid ${K.gd}25`:"none"}}>
          {m.role==="ai"&&<div style={{fontSize:8,color:K.gd,marginBottom:3,fontWeight:600}}>بصيرة</div>}
          {m.text}
        </div>
      </div>)}
      {chatLoading&&<div style={{display:"flex",justifyContent:"flex-end",marginBottom:8}}><div style={{padding:"8px 12px",borderRadius:"12px 12px 12px 4px",background:`${K.gd}15`,border:`1px solid ${K.gd}25`,color:K.gd,fontSize:10}}><RefreshCw size={11} style={{animation:"sp 1s linear infinite"}}/> أفكر...<style>{`@keyframes sp{to{transform:rotate(360deg)}}`}</style></div></div>}
    </div>
    <div style={{padding:8,borderTop:`1px solid ${K.bd}`,display:"flex",gap:6}}>
      <input value={chatInput} onChange={e=>setChatInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendChat()} placeholder="اسأل بصيرة عن أي سهم سعودي..." style={{flex:1,background:K.nv,border:`1px solid ${K.bd}`,borderRadius:8,padding:"8px 12px",color:K.tx,fontSize:11,outline:"none"}}/>
      <button onClick={sendChat} disabled={chatLoading} style={{background:K.gd,border:"none",borderRadius:8,padding:"8px 14px",color:K.nv,cursor:"pointer",fontWeight:700,fontSize:11,opacity:chatLoading?.5:1}}><Send size={14}/></button>
    </div>
  </Cd>
</div>}

{/* ══ SCREENER ══ */}
{pg==="screener"&&<div>
  <div style={{display:"flex",gap:2,marginBottom:8,flexWrap:"wrap"}}>{[{id:null,l:"الكل"},{id:"value",l:"قيمة"},{id:"quality",l:"جودة"},{id:"growth",l:"نمو"},{id:"momentum",l:"زخم"},{id:"dividend",l:"توزيعات"},{id:"lowrisk",l:"أقل مخاطر"},{id:"buffett",l:"بافيت"}].map(f=><Bt key={f.id||"a"} ch={f.l} act={fl===f.id} onClick={()=>setFl(f.id)} sm/>)}</div>
  <Cd><div style={{overflowX:"auto"}}><table style={{width:"100%",borderCollapse:"collapse",fontSize:9}}><thead><tr style={{background:K.nv}}>{["#","رمز","اسم","قطاع","سعر","تغير","P/E","ROE","عائد","بيتا","نمو","درجة"].map(h=><th key={h} style={{padding:"5px 4px",textAlign:"right",color:K.mt,fontSize:8}}>{h}</th>)}</tr></thead><tbody>{scr.map((s,i)=><tr key={s.c} onClick={()=>go(s.c)} style={{cursor:"pointer",borderBottom:`1px solid ${K.bd}`}} onMouseEnter={e=>e.currentTarget.style.background=K.ch} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><td style={{padding:"5px 4px",color:K.mt}}>{i+1}</td><td style={{fontWeight:600}}>{s.c}</td><td>{s.n}</td><td style={{color:K.mt}}>{s.s}</td><td style={{fontWeight:600}}>{s.p.toFixed(2)}</td><td style={{color:s.ch>=0?K.gn:K.rd}}>{s.ch>=0?"+":""}{s.ch}%</td><td>{s.pe}</td><td>{s.roe}%</td><td>{s.dy}%</td><td>{s.bt}</td><td style={{color:s.ng>0?K.gn:K.rd}}>{s.ng}%</td><td><SB v={s.sc}/></td></tr>)}</tbody></table></div></Cd>
</div>}

{/* ══ PORTFOLIO ══ */}
{pg==="portfolio"&&<div>
  <div style={{display:"flex",gap:5,marginBottom:8,flexWrap:"wrap"}}><Mt l="القيمة" val={`${pfD.tv.toFixed(0)}`}/><Mt l="الربح" val={`${pfD.pnl>=0?"+":""}${pfD.pnl.toFixed(0)}`} sub={`${pfD.pnlP.toFixed(1)}%`} tr={pfD.pnl>=0?"u":"d"}/><Mt l="دخل سنوي" val={`${pfD.annDiv.toFixed(0)}`} ic={DollarSign}/></div>
  <Cd style={{padding:8,marginBottom:8}}><ResponsiveContainer width="100%" height={130}><LineChart data={PERF}><CartesianGrid strokeDasharray="3 3" stroke={K.bd} opacity={.3}/><XAxis dataKey="d" tick={{fill:K.mt,fontSize:7}} axisLine={false}/><YAxis tick={{fill:K.mt,fontSize:7}} axisLine={false}/><Tooltip contentStyle={{background:K.nv,border:`1px solid ${K.bd}`,borderRadius:5,fontSize:8}}/><Legend wrapperStyle={{fontSize:8}}/><Line type="monotone" dataKey="pf" name="محفظتي" stroke={K.gd} strokeWidth={2} dot={false}/><Line type="monotone" dataKey="tasi" name="تاسي" stroke={K.bl} strokeWidth={1.5} dot={false} strokeDasharray="4 2"/></LineChart></ResponsiveContainer></Cd>
  <div style={{display:"grid",gridTemplateColumns:"5fr 2fr",gap:8}}>
    <Cd><div style={{overflowX:"auto"}}><table style={{width:"100%",borderCollapse:"collapse",fontSize:9}}><thead><tr style={{background:K.nv}}>{["سهم","كمية","متوسط","حالي","ربح","وزن","درجة",""].map(h=><th key={h} style={{padding:"4px 3px",color:K.mt,fontSize:8,textAlign:"right"}}>{h}</th>)}</tr></thead><tbody>{pfD.items.map(p=><tr key={p.c} style={{borderBottom:`1px solid ${K.bd}`}}><td style={{padding:"4px 3px",fontWeight:600,cursor:"pointer"}} onClick={()=>go(p.c)}>{p.nm}</td><td>{p.q}</td><td>{p.a.toFixed(2)}</td><td style={{fontWeight:600}}>{p.cp.toFixed(2)}</td><td style={{color:p.pnl>=0?K.gn:K.rd}}>{p.pnl>=0?"+":""}{p.pnl.toFixed(0)} ({p.pnlP.toFixed(1)}%)</td><td>{p.w.toFixed(1)}%</td><td><SB v={p.sc}/></td><td><button onClick={()=>setPf(pf.filter(x=>x.c!==p.c))} style={{background:"none",border:"none",cursor:"pointer",color:K.rd}}><Trash2 size={10}/></button></td></tr>)}</tbody></table></div></Cd>
    <Cd style={{padding:8}}><ResponsiveContainer width="100%" height={120}><PieChart><Pie data={pfD.secs} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={50} innerRadius={28}>{pfD.secs.map((_,i)=><Cell key={i} fill={PC[i%PC.length]}/>)}</Pie></PieChart></ResponsiveContainer>{pfD.secs.map((s,i)=><div key={s.name} style={{display:"flex",justifyContent:"space-between",fontSize:8,padding:"1px 0"}}><div style={{display:"flex",gap:2,alignItems:"center"}}><div style={{width:5,height:5,borderRadius:1,background:PC[i%PC.length]}}/>{s.name}</div><span style={{fontWeight:600}}>{s.value}%</span></div>)}</Cd>
  </div>
</div>}

{/* ══ COMPARE ══ */}
{pg==="compare"&&<div>
  <div style={{display:"flex",gap:4,marginBottom:8}}><select value={sel} onChange={e=>setSel(e.target.value)} style={{background:K.cd,color:K.tx,border:`1px solid ${K.bd}`,borderRadius:5,padding:"3px 5px",fontSize:10}}>{Object.entries(S).map(([c,s])=><option key={c} value={c}>{s.n}</option>)}</select><span style={{color:K.mt,alignSelf:"center"}}>vs</span><select value={cs} onChange={e=>setCs(e.target.value)} style={{background:K.cd,color:K.tx,border:`1px solid ${K.bd}`,borderRadius:5,padding:"3px 5px",fontSize:10}}>{Object.entries(S).map(([c,s])=><option key={c} value={c}>{s.n}</option>)}</select></div>
  {st&&S[cs]&&<><Cd style={{padding:8,marginBottom:8}}><ResponsiveContainer width="100%" height={160}><LineChart data={st.pr.map((p,i)=>({d:i+1,s1:((p/st.pr[0])-1)*100,s2:((S[cs].pr[i]/S[cs].pr[0])-1)*100}))}><CartesianGrid strokeDasharray="3 3" stroke={K.bd} opacity={.3}/><XAxis dataKey="d" tick={{fill:K.mt,fontSize:7}} axisLine={false}/><YAxis tick={{fill:K.mt,fontSize:7}} axisLine={false} tickFormatter={v=>`${v.toFixed(0)}%`}/><Tooltip contentStyle={{background:K.nv,border:`1px solid ${K.bd}`,borderRadius:5,fontSize:8}} formatter={v=>[`${v.toFixed(2)}%`]}/><Legend wrapperStyle={{fontSize:8}}/><Line type="monotone" dataKey="s1" name={st.n} stroke={K.bl} strokeWidth={2} dot={false}/><Line type="monotone" dataKey="s2" name={S[cs].n} stroke={K.gd} strokeWidth={2} dot={false}/></LineChart></ResponsiveContainer></Cd>
  <Cd style={{padding:10}}><table style={{width:"100%",borderCollapse:"collapse",fontSize:10}}><thead><tr><th style={{padding:4,color:K.mt,textAlign:"right"}}>المؤشر</th><th style={{padding:4,textAlign:"center",color:K.bl}}>{st.n}</th><th style={{padding:4,textAlign:"center",color:K.gd}}>{S[cs].n}</th></tr></thead><tbody>{[["تغير",`${st.ch}%`,`${S[cs].ch}%`],["P/E",st.pe,S[cs].pe],["عائد",`${st.dy}%`,`${S[cs].dy}%`],["ROE",`${st.roe}%`,`${S[cs].roe}%`],["بيتا",st.bt,S[cs].bt],["درجة",st.sc,S[cs].sc]].map(([l,v1,v2],i)=><tr key={i} style={{borderBottom:`1px solid ${K.bd}`}}><td style={{padding:4,color:K.dm}}>{l}</td><td style={{padding:4,textAlign:"center",fontWeight:600}}>{v1}</td><td style={{padding:4,textAlign:"center",fontWeight:600}}>{v2}</td></tr>)}</tbody></table></Cd></>}
</div>}

{/* ══ SECTORS ══ */}
{pg==="sectors"&&<div>
  <Cd style={{padding:8,marginBottom:8}}><ResponsiveContainer width="100%" height={200}><BarChart data={SP.sort((a,b)=>b.pf-a.pf)} layout="vertical"><CartesianGrid strokeDasharray="3 3" stroke={K.bd} opacity={.3}/><XAxis type="number" tick={{fill:K.mt,fontSize:8}} axisLine={false}/><YAxis dataKey="n" type="category" tick={{fill:K.tx,fontSize:9}} axisLine={false} width={70}/><Tooltip contentStyle={{background:K.nv,border:`1px solid ${K.bd}`,borderRadius:5,fontSize:9}}/><Bar dataKey="pf" radius={[0,3,3,0]}>{SP.sort((a,b)=>b.pf-a.pf).map((s,i)=><Cell key={i} fill={s.pf>=0?K.gn:K.rd}/>)}</Bar></BarChart></ResponsiveContainer></Cd>
  <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6}}>{SP.map(sec=>{const stocks=Object.entries(S).filter(([,s])=>s.s===sec.n).sort(([,a],[,b])=>b.sc-a.sc).slice(0,3);return stocks.length>0&&<Cd key={sec.n} style={{padding:8}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontWeight:600,fontSize:10}}>{sec.n}</span><Bd ch={`${sec.pf>=0?"+":""}${sec.pf}%`} cl={sec.pf>=0?"gn":"rd"}/></div>{stocks.map(([c,s])=><div key={c} onClick={()=>go(c)} style={{display:"flex",justifyContent:"space-between",padding:"3px 0",borderBottom:`1px solid ${K.bd}`,cursor:"pointer",fontSize:10}}><span>{s.n}</span><SB v={s.sc}/></div>)}</Cd>})}</div>
</div>}

{/* ══ REPORTS ══ */}
{pg==="reports"&&<div>
  <Cd style={{padding:10,marginBottom:8}}><div style={{display:"flex",gap:6,flexWrap:"wrap",alignItems:"flex-end"}}><select value={sel} onChange={e=>setSel(e.target.value)} style={{background:K.nv,color:K.tx,border:`1px solid ${K.bd}`,borderRadius:5,padding:"3px 5px",fontSize:10}}>{Object.entries(S).map(([c,s])=><option key={c} value={c}>{s.n}</option>)}</select><div style={{display:"flex",gap:2}}>{["مؤسسي","فني","مخاطر","توزيعات"].map(t=><Bt key={t} ch={t} act={tb===t} onClick={()=>setTb(t)} sm/>)}</div><Bt ch="إنشاء" act onClick={()=>runAI(`تقرير ${tb} مفصل`)} dis={aiL}/></div></Cd>
  {aiL&&<div style={{color:K.gd,padding:16,textAlign:"center",fontSize:10}}><RefreshCw size={12} style={{animation:"sp 1s linear infinite"}}/><style>{`@keyframes sp{to{transform:rotate(360deg)}}`}</style></div>}
  {aiR&&!aiL&&<Cd style={{padding:12}}><div style={{display:"flex",justifyContent:"space-between",borderBottom:`1px solid ${K.bd}`,paddingBottom:6,marginBottom:8}}><div style={{fontSize:12,fontWeight:700,color:K.gd}}>تقرير {tb} - {S[sel]?.n}</div><button onClick={()=>navigator.clipboard?.writeText(aiR)} style={{background:`${K.bl}15`,border:`1px solid ${K.bl}30`,borderRadius:4,padding:"3px 6px",color:K.bl,cursor:"pointer",fontSize:8}}><Copy size={9}/> نسخ</button></div><div style={{whiteSpace:"pre-wrap",fontSize:10,lineHeight:1.9}}>{aiR}</div></Cd>}
</div>}

{/* ══ CHECKLIST ══ */}
{pg==="checklist"&&<div>
  <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}><span style={{fontSize:15,fontWeight:700,color:K.gd}}>تشيك ليست</span><select value={sel} onChange={e=>setSel(e.target.value)} style={{background:K.cd,color:K.tx,border:`1px solid ${K.bd}`,borderRadius:5,padding:"3px 5px",fontSize:10}}>{Object.entries(S).map(([c,s])=><option key={c} value={c}>{s.n}</option>)}</select></div>
  {st&&<><Cd style={{padding:10,marginBottom:6}}><div style={{display:"flex",justifyContent:"space-between"}}><span style={{fontWeight:700}}>{st.n}</span><span style={{fontSize:16,fontWeight:800,color:passN>=9?K.gn:passN>=6?K.gd:K.rd}}>{passN}/{cl.length}</span></div><div style={{height:5,background:K.nv,borderRadius:3,marginTop:4}}><div style={{width:`${passN/cl.length*100}%`,height:"100%",background:passN>=9?K.gn:passN>=6?K.gd:K.rd,borderRadius:3}}/></div></Cd>
  {cl.map((c,i)=><Cd key={i} style={{padding:"6px 10px",marginBottom:2,borderRight:`3px solid ${c.p?K.gn:K.rd}`}}><div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><div style={{display:"flex",gap:5,alignItems:"center"}}>{c.p?<CheckCircle size={12} color={K.gn}/>:<XCircle size={12} color={K.rd}/>}<span style={{fontSize:10}}>{c.q} <span style={{color:K.dm}}>({c.a})</span></span></div></div></Cd>)}</>}
</div>}

{/* ══ ALERTS ══ */}
{pg==="alerts"&&<div>
  {[{cl:K.bl,ti:"الراجحي كسر 96",ds:"حجم +40%",stk:"1120"},{cl:K.gd,ti:"نتائج أرامكو قريباً",ds:"توقعات +8%",stk:"2222"},{cl:K.rd,ti:"تركّز 42% بنوك",ds:"تنويع مطلوب"},{cl:K.gn,ti:"البحري حجم +60%",ds:"اهتمام مؤسسي",stk:"4030"},{cl:K.gd,ti:"أحقية STC أسبوعين",ds:"2 ر.س/سهم",stk:"7010"},{cl:K.or,ti:"كيان درجة 35",ds:"تراجع أرباح",stk:"2350"},{cl:K.bl,ti:"بدجت فوق MA200",ds:"إشارة صعودية",stk:"4260"},{cl:K.gn,ti:"التعاونية +2.1%",ds:"زخم قوي مستمر",stk:"8010"}].map((a,i)=><Cd key={i} style={{marginBottom:4,borderRight:`3px solid ${a.cl}`,cursor:a.stk?"pointer":"default"}} onClick={()=>a.stk&&go(a.stk)}><div style={{padding:8}}><div style={{fontWeight:600,fontSize:11}}>{a.ti}</div><div style={{fontSize:9,color:K.dm}}>{a.ds}</div></div></Cd>)}
</div>}

{/* ══ SETTINGS ══ */}
{pg==="settings"&&<div>
  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
    <Cd style={{padding:10}}>{[{id:"مستثمر",ic:Target},{id:"مضارب",ic:Zap},{id:"مدير",ic:Briefcase}].map(m=><div key={m.id} onClick={()=>setVm(m.id)} style={{display:"flex",alignItems:"center",gap:6,padding:8,borderRadius:5,cursor:"pointer",background:vm===m.id?`${K.gd}12`:"transparent",border:`1px solid ${vm===m.id?K.gd:K.bd}`,marginBottom:4}}><m.ic size={14} color={vm===m.id?K.gd:K.mt}/><span style={{fontWeight:600,color:vm===m.id?K.gd:K.tx,fontSize:11}}>{m.id}</span></div>)}</Cd>
    <Cd style={{padding:10}}><div style={{fontSize:12,fontWeight:700,color:K.gd,marginBottom:6}}>تداول بصيرة v5.0</div><div style={{fontSize:9,color:K.dm,lineHeight:1.9}}>
      <strong>12 شاشة</strong> · <strong>{totalStocks} سهم</strong> · <strong>8 فلاتر</strong><br/>
      <strong style={{color:K.gd}}>جديد v5:</strong> محادثة AI تفاعلية · نظرة عامة على السوق (عمق، أنشط، أكثر ارتفاعاً/انخفاضاً) · 20 سهم سعودي · رسم السعر+الحجم معاً · 8 تنبيهات ذكية · أسهم جديدة: التعاونية، زين، أسمنت العربية، الجنوبية، بدجت، المتقدمة، الأندلس، البنك الأول
    </div></Cd>
  </div>
</div>}

      </div></div></div>);
}
