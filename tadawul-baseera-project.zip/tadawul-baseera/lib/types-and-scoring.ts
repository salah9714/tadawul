/**
 * تداول بصيرة - أنواع البيانات ومكتبة التسجيل
 * Tadawul Baseera - Types & Scoring Library
 */

// ═══════════════════════════════════════
// أنواع البيانات (Types)
// ═══════════════════════════════════════

export interface Stock {
  code: string;
  name: string;
  nameEn: string;
  sector: string;
  market: "رئيسي" | "نمو";

  // السعر والتداول
  price: number;
  change: number; // نسبة التغير %
  volume: number; // بالمليون
  marketCap: number; // بالمليار

  // النسب المالية
  pe: number;
  pb: number;
  dividendYield: number;
  roe: number;
  debtToEquity: number;
  beta: number;
  eps: number;
  netMargin: number;
  revenueGrowth: number;
  earningsGrowth: number;
  dividendGrowth: number;

  // البيانات المطلقة
  revenue: number; // بالمليار
  netIncome: number;
  fcf: number;

  // التقييمات
  dividendSafety: number; // 0-100
  compositeScore: number; // 0-100

  // المؤشرات الفنية
  rsi: number;
  macd: number;
  sma50: number;
  sma200: number;
  support: number;
  resistance: number;
  trend: "صاعد" | "هابط" | "عرضي";

  // البيانات التاريخية
  prices: number[]; // آخر 24 إغلاق
  volumes: number[]; // آخر 24 حجم

  // الأرباح
  earnings: EarningsResult[];

  // التوزيعات
  dividendHistory: DividendRecord[];

  // معلومات نوعية
  moat?: string;
  risks?: string;
}

export interface EarningsResult {
  quarter: string; // "Q1-2025"
  epsActual: number;
  epsEstimate: number;
  revenue?: number;
  priceReaction: number; // % تغير السعر بعد الإعلان
}

export interface DividendRecord {
  year: string;
  amount: number;
}

export interface DividendEvent {
  code: string;
  name: string;
  date: string;
  type: "أحقية" | "توزيع" | "جمعية";
  amount?: string;
  yield?: number;
}

export interface PortfolioItem {
  code: string;
  quantity: number;
  averagePrice: number;
}

export interface WatchlistItem {
  code: string;
  notes?: string;
  addedAt: string;
}

export interface Alert {
  id: string;
  stockCode?: string;
  type: "سعر" | "RSI" | "كسر مقاومة" | "كسر دعم" | "نتائج" | "محفظة";
  condition: string;
  value: string;
  active: boolean;
  createdAt: string;
}

export interface PortfolioAnalysis {
  items: PortfolioHolding[];
  totalValue: number;
  totalCost: number;
  pnl: number;
  pnlPercent: number;
  sectors: SectorWeight[];
  annualDividendIncome: number;
}

export interface PortfolioHolding extends PortfolioItem {
  name: string;
  sector: string;
  currentPrice: number;
  value: number;
  cost: number;
  pnl: number;
  pnlPercent: number;
  weight: number;
  score: number;
  dividendYield: number;
}

export interface SectorWeight {
  name: string;
  value: number; // النسبة المئوية
}

export interface SectorPerformance {
  name: string;
  dayChange: number;
  weekChange: number;
  monthChange: number;
  classification: "هجومي" | "محايد" | "دفاعي";
  topStocks: string[];
}

export interface ChecklistItem {
  question: string;
  answer: string;
  passed: boolean;
}

export type ViewMode = "مستثمر" | "مضارب" | "مدير";
export type ReportType = "مؤسسي" | "فني" | "مخاطر" | "توزيعات" | "مقارنة";

// ═══════════════════════════════════════
// حساب الدرجة المركبة
// ═══════════════════════════════════════

export interface ScoringWeights {
  value: number;
  quality: number;
  growth: number;
  dividend: number;
  risk: number;
  momentum: number;
}

const DEFAULT_WEIGHTS: ScoringWeights = {
  value: 20,
  quality: 20,
  growth: 15,
  dividend: 15,
  risk: 15,
  momentum: 15,
};

/**
 * حساب الدرجة المركبة للسهم
 * من 0 إلى 100
 */
export function calculateCompositeScore(
  stock: Pick<
    Stock,
    "pe" | "pb" | "roe" | "dividendYield" | "beta" | "earningsGrowth" | "dividendSafety" | "rsi" | "trend"
  >,
  weights: ScoringWeights = DEFAULT_WEIGHTS
): number {
  let score = 0;
  const total = Object.values(weights).reduce((a, b) => a + b, 0);

  // === القيمة (Value) ===
  const valueScore =
    stock.pe <= 0 ? 5 :
    stock.pe < 12 ? 100 :
    stock.pe < 15 ? 80 :
    stock.pe < 20 ? 60 :
    stock.pe < 25 ? 40 :
    stock.pe < 35 ? 20 : 10;
  score += (valueScore * weights.value) / total;

  // === الجودة (Quality) ===
  const qualityScore =
    stock.roe > 25 ? 100 :
    stock.roe > 18 ? 80 :
    stock.roe > 12 ? 60 :
    stock.roe > 8 ? 40 : 20;
  score += (qualityScore * weights.quality) / total;

  // === النمو (Growth) ===
  const growthScore =
    stock.earningsGrowth > 20 ? 100 :
    stock.earningsGrowth > 12 ? 80 :
    stock.earningsGrowth > 5 ? 60 :
    stock.earningsGrowth > 0 ? 40 : 15;
  score += (growthScore * weights.growth) / total;

  // === التوزيعات (Dividends) ===
  const divScore =
    stock.dividendYield > 5 ? 100 :
    stock.dividendYield > 3.5 ? 80 :
    stock.dividendYield > 2 ? 60 :
    stock.dividendYield > 1 ? 40 : 20;
  score += (divScore * weights.dividend) / total;

  // === المخاطر (Risk) - أقل = أفضل ===
  const riskScore =
    stock.beta < 0.7 ? 100 :
    stock.beta < 0.9 ? 80 :
    stock.beta < 1.1 ? 60 :
    stock.beta < 1.3 ? 40 : 20;
  score += (riskScore * weights.risk) / total;

  // === الزخم (Momentum) ===
  const momentumScore =
    stock.trend === "صاعد" && stock.rsi > 40 && stock.rsi < 70 ? 100 :
    stock.trend === "صاعد" ? 75 :
    stock.trend === "عرضي" ? 50 : 25;
  score += (momentumScore * weights.momentum) / total;

  return Math.round(Math.max(0, Math.min(100, score)));
}

/**
 * حساب أمان التوزيعات
 */
export function calculateDividendSafety(
  dividendYield: number,
  pe: number,
  fcf: number,
  debtToEquity: number,
  earningsGrowth: number
): number {
  let score = 50;

  // نسبة التوزيع من الأرباح
  if (pe > 0 && dividendYield > 0) {
    const payoutRatio = (dividendYield * pe) / 100;
    if (payoutRatio < 0.3) score += 20;
    else if (payoutRatio < 0.5) score += 10;
    else if (payoutRatio < 0.7) score += 0;
    else if (payoutRatio < 0.9) score -= 10;
    else score -= 20;
  }

  // التدفقات النقدية
  if (fcf > 0) score += 10;
  else score -= 15;

  // الديون
  if (debtToEquity < 0.3) score += 10;
  else if (debtToEquity > 0.6) score -= 10;

  // نمو الأرباح
  if (earningsGrowth > 5) score += 10;
  else if (earningsGrowth < -5) score -= 10;

  return Math.round(Math.max(0, Math.min(100, score)));
}

/**
 * تشيك ليست المستثمر
 */
export function generateChecklist(stock: Stock): ChecklistItem[] {
  return [
    {
      question: "هل تفهم نموذج عمل الشركة؟",
      answer: stock.moat || "يحتاج بحث",
      passed: !!stock.moat,
    },
    {
      question: "هل مكرر الربحية معقول؟",
      answer: `P/E = ${stock.pe} (${stock.pe < 15 ? "جذاب" : stock.pe < 20 ? "معقول" : "مرتفع"})`,
      passed: stock.pe > 0 && stock.pe < 20,
    },
    {
      question: "هل العائد على حقوق الملكية جيد؟",
      answer: `ROE = ${stock.roe}%`,
      passed: stock.roe > 12,
    },
    {
      question: "هل الديون تحت السيطرة؟",
      answer: `D/E = ${stock.debtToEquity}`,
      passed: stock.debtToEquity < 0.5,
    },
    {
      question: "هل هناك نمو في الأرباح؟",
      answer: `${stock.earningsGrowth}%`,
      passed: stock.earningsGrowth > 0,
    },
    {
      question: "هل التوزيعات آمنة ومستدامة؟",
      answer: `أمان: ${stock.dividendSafety}/100`,
      passed: stock.dividendSafety > 60,
    },
    {
      question: "هل عائد التوزيع مجزٍ؟",
      answer: `${stock.dividendYield}%`,
      passed: stock.dividendYield > 2.5,
    },
    {
      question: "هل الاتجاه الفني إيجابي؟",
      answer: stock.trend,
      passed: stock.trend === "صاعد",
    },
    {
      question: "هل السهم فوق المتوسط 200؟",
      answer: `${stock.price} vs ${stock.sma200}`,
      passed: stock.price > stock.sma200,
    },
    {
      question: "هل التدفقات النقدية إيجابية؟",
      answer: `FCF = ${stock.fcf} مليار`,
      passed: stock.fcf > 0,
    },
    {
      question: "هل بيتا مناسب لتحملك؟",
      answer: `β = ${stock.beta}`,
      passed: stock.beta < 1.2,
    },
    {
      question: "هل الدرجة المركبة جيدة؟",
      answer: `${stock.compositeScore}/100`,
      passed: stock.compositeScore > 55,
    },
  ];
}

/**
 * حساب تحليل المحفظة
 */
export function analyzePortfolio(
  holdings: PortfolioItem[],
  stocks: Record<string, Stock>
): PortfolioAnalysis {
  let totalValue = 0;
  let totalCost = 0;

  const items: PortfolioHolding[] = holdings
    .map((h) => {
      const stock = stocks[h.code];
      if (!stock) return null;
      const value = stock.price * h.quantity;
      const cost = h.averagePrice * h.quantity;
      totalValue += value;
      totalCost += cost;
      return {
        ...h,
        name: stock.name,
        sector: stock.sector,
        currentPrice: stock.price,
        value,
        cost,
        pnl: value - cost,
        pnlPercent: ((value / cost) - 1) * 100,
        weight: 0,
        score: stock.compositeScore,
        dividendYield: stock.dividendYield,
      };
    })
    .filter(Boolean) as PortfolioHolding[];

  items.forEach((i) => (i.weight = (i.value / totalValue) * 100));

  const sectorMap: Record<string, number> = {};
  items.forEach((i) => {
    sectorMap[i.sector] = (sectorMap[i.sector] || 0) + i.value;
  });

  const sectors = Object.entries(sectorMap).map(([name, value]) => ({
    name,
    value: +((value / totalValue) * 100).toFixed(1),
  }));

  const annualDividendIncome = items.reduce((acc, item) => {
    return acc + (item.dividendYield / 100) * item.value;
  }, 0);

  return {
    items,
    totalValue,
    totalCost,
    pnl: totalValue - totalCost,
    pnlPercent: ((totalValue / totalCost) - 1) * 100,
    sectors,
    annualDividendIncome,
  };
}

/**
 * فرز الأسهم حسب الفلتر
 */
export type ScreenerFilter =
  | "composite"
  | "value"
  | "quality"
  | "growth"
  | "momentum"
  | "dividend"
  | "lowrisk"
  | "buffett";

export function sortStocksByFilter(
  stocks: Stock[],
  filter: ScreenerFilter
): Stock[] {
  const sorted = [...stocks];
  switch (filter) {
    case "value":
      return sorted.sort((a, b) => a.pe - b.pe);
    case "quality":
      return sorted.sort((a, b) => b.roe - a.roe);
    case "growth":
      return sorted.sort((a, b) => b.earningsGrowth - a.earningsGrowth);
    case "momentum":
      return sorted.sort((a, b) => b.change - a.change);
    case "dividend":
      return sorted.sort((a, b) => b.dividendYield - a.dividendYield);
    case "lowrisk":
      return sorted.sort((a, b) => a.beta - b.beta);
    case "buffett":
      return sorted.sort(
        (a, b) =>
          b.roe - b.pe + b.dividendSafety / 10 -
          (a.roe - a.pe + a.dividendSafety / 10)
      );
    default:
      return sorted.sort((a, b) => b.compositeScore - a.compositeScore);
  }
}
