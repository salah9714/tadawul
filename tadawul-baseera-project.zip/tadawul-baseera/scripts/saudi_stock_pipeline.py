#!/usr/bin/env python3
"""
تداول بصيرة - سكريبت جلب بيانات الأسهم السعودية
Tadawul Baseera - Saudi Stock Data Pipeline

يجلب بيانات الأسهم السعودية من Yahoo Finance ويحفظها بصيغة JSON
جاهزة للاستخدام في النظام.

الاستخدام:
    pip install yfinance pandas --break-system-packages
    python saudi_stock_pipeline.py

المخرج:
    saudi_stocks_data.json - بيانات كاملة لجميع الأسهم
"""

import json
import datetime
from pathlib import Path

# ══════════════════════════════════════════════
# قائمة الأسهم السعودية المدرجة في تداول
# الرمز على Yahoo Finance = رمز_تداول.SR
# ══════════════════════════════════════════════

SAUDI_STOCKS = {
    # === البنوك ===
    "1120": {"name": "الراجحي", "en": "Al Rajhi Bank", "sector": "البنوك"},
    "1180": {"name": "الأهلي السعودي", "en": "SNB", "sector": "البنوك"},
    "1010": {"name": "الرياض", "en": "Riyad Bank", "sector": "البنوك"},
    "1150": {"name": "البنك الأول", "en": "SAB", "sector": "البنوك"},
    "1050": {"name": "البنك السعودي الفرنسي", "en": "BSF", "sector": "البنوك"},
    "1020": {"name": "الجزيرة", "en": "Bank AlJazira", "sector": "البنوك"},
    "1030": {"name": "الاستثمار", "en": "SAIB", "sector": "البنوك"},
    "1060": {"name": "البلاد", "en": "Bank Albilad", "sector": "البنوك"},
    "1080": {"name": "العربي", "en": "Arab National Bank", "sector": "البنوك"},

    # === الطاقة ===
    "2222": {"name": "أرامكو السعودية", "en": "Saudi Aramco", "sector": "الطاقة"},
    "4200": {"name": "الدريس", "en": "Aldrees", "sector": "الطاقة"},

    # === المواد الأساسية ===
    "2010": {"name": "سابك", "en": "SABIC", "sector": "المواد الأساسية"},
    "2350": {"name": "كيان السعودية", "en": "Kayan", "sector": "المواد الأساسية"},
    "2060": {"name": "التصنيع", "en": "Tasnee", "sector": "المواد الأساسية"},
    "2310": {"name": "سبكيم", "en": "Sipchem", "sector": "المواد الأساسية"},
    "4002": {"name": "المتقدمة", "en": "APPC", "sector": "المواد الأساسية"},

    # === الاتصالات ===
    "7010": {"name": "STC", "en": "STC", "sector": "الاتصالات"},
    "7020": {"name": "الاتصالات المتنقلة", "en": "Mobily", "sector": "الاتصالات"},
    "2150": {"name": "زين السعودية", "en": "Zain KSA", "sector": "الاتصالات"},

    # === التجزئة ===
    "4190": {"name": "جرير", "en": "Jarir", "sector": "التجزئة"},
    "4003": {"name": "إكسترا", "en": "Extra", "sector": "التجزئة"},

    # === النقل ===
    "4030": {"name": "البحري", "en": "Bahri", "sector": "النقل"},
    "4260": {"name": "بدجت", "en": "Budget Saudi", "sector": "النقل"},

    # === الأغذية ===
    "2280": {"name": "المراعي", "en": "Almarai", "sector": "الأغذية"},
    "2050": {"name": "صافولا", "en": "Savola", "sector": "الأغذية"},
    "6010": {"name": "نادك", "en": "NADEC", "sector": "الأغذية"},

    # === التأمين ===
    "8010": {"name": "التعاونية", "en": "Tawuniya", "sector": "التأمين"},
    "8020": {"name": "ملاذ", "en": "Malath", "sector": "التأمين"},

    # === الأسمنت ===
    "3010": {"name": "أسمنت العربية", "en": "Arabian Cement", "sector": "الأسمنت"},
    "4001": {"name": "أسمنت الجنوبية", "en": "Southern Cement", "sector": "الأسمنت"},
    "3020": {"name": "أسمنت اليمامة", "en": "Yamama Cement", "sector": "الأسمنت"},

    # === العقار ===
    "4321": {"name": "الأندلس", "en": "Andalus", "sector": "العقار"},
    "4300": {"name": "دار الأركان", "en": "Dar Al Arkan", "sector": "العقار"},
    "4020": {"name": "العقارية", "en": "SRECO", "sector": "العقار"},

    # === الرعاية الصحية ===
    "4004": {"name": "دله الصحية", "en": "Dallah Healthcare", "sector": "الرعاية الصحية"},
    "4005": {"name": "رعاية", "en": "Care", "sector": "الرعاية الصحية"},

    # === المرافق ===
    "5110": {"name": "الكهرباء", "en": "SEC", "sector": "المرافق"},
}


def fetch_stock_data(ticker_code: str, info: dict) -> dict:
    """
    جلب بيانات سهم واحد من Yahoo Finance

    Args:
        ticker_code: رمز التداول (مثل "2222")
        info: معلومات السهم الأساسية

    Returns:
        dict: بيانات السهم الكاملة
    """
    try:
        import yfinance as yf

        yahoo_ticker = f"{ticker_code}.SR"
        stock = yf.Ticker(yahoo_ticker)

        # الأسعار التاريخية - آخر 6 أشهر
        hist = stock.history(period="6mo")
        if hist.empty:
            print(f"  ⚠ لا توجد بيانات لـ {info['name']} ({ticker_code})")
            return None

        # آخر سعر
        last_price = round(hist['Close'].iloc[-1], 2)
        prev_price = round(hist['Close'].iloc[-2], 2) if len(hist) > 1 else last_price
        change_pct = round((last_price - prev_price) / prev_price * 100, 2)

        # آخر 24 سعر إغلاق
        prices = [round(p, 2) for p in hist['Close'].tail(24).tolist()]

        # أحجام التداول (بالمليون)
        volumes = [round(v / 1e6, 1) for v in hist['Volume'].tail(24).tolist()]

        # المعلومات الأساسية
        stock_info = stock.info or {}

        # النسب المالية
        pe = round(stock_info.get('trailingPE', 0) or 0, 1)
        pb = round(stock_info.get('priceToBook', 0) or 0, 1)
        dy = round((stock_info.get('dividendYield', 0) or 0) * 100, 1)
        roe = round((stock_info.get('returnOnEquity', 0) or 0) * 100, 1)
        eps = round(stock_info.get('trailingEps', 0) or 0, 2)
        beta = round(stock_info.get('beta', 1) or 1, 2)
        market_cap = round((stock_info.get('marketCap', 0) or 0) / 1e9, 1)
        de = round(stock_info.get('debtToEquity', 0) or 0, 2) / 100 if stock_info.get('debtToEquity') else 0
        profit_margin = round((stock_info.get('profitMargins', 0) or 0) * 100, 1)
        revenue = round((stock_info.get('totalRevenue', 0) or 0) / 1e9, 1)
        net_income = round((stock_info.get('netIncomeToCommon', 0) or 0) / 1e9, 1)
        fcf = round((stock_info.get('freeCashflow', 0) or 0) / 1e9, 1)
        revenue_growth = round((stock_info.get('revenueGrowth', 0) or 0) * 100, 1)
        earnings_growth = round((stock_info.get('earningsGrowth', 0) or 0) * 100, 1)

        # المؤشرات الفنية
        if len(hist) >= 50:
            ma50 = round(hist['Close'].tail(50).mean(), 2)
        else:
            ma50 = last_price

        if len(hist) >= 120:
            ma200 = round(hist['Close'].tail(120).mean(), 2)  # تقريبي
        else:
            ma200 = last_price

        # RSI (14 يوم)
        delta = hist['Close'].diff()
        gain = delta.where(delta > 0, 0).rolling(14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
        rs = gain / loss
        rsi_series = 100 - (100 / (1 + rs))
        rsi = round(rsi_series.iloc[-1], 0) if not rsi_series.empty else 50

        # الدعم والمقاومة (تقريبي)
        recent = hist['Close'].tail(30)
        support = round(recent.min(), 2)
        resistance = round(recent.max(), 2)

        # الاتجاه
        if last_price > ma50 > ma200:
            trend = "صاعد"
        elif last_price < ma50 < ma200:
            trend = "هابط"
        else:
            trend = "عرضي"

        # حساب أمان التوزيعات (تقريبي)
        div_safety = 50  # افتراضي
        if dy > 0 and pe > 0:
            payout = dy * pe / 100
            if payout < 0.4:
                div_safety = 90
            elif payout < 0.6:
                div_safety = 75
            elif payout < 0.8:
                div_safety = 60
            else:
                div_safety = 40

        # الدرجة المركبة
        score = calculate_composite_score(pe, pb, roe, dy, beta, earnings_growth, div_safety, rsi, trend)

        # التوزيعات التاريخية
        divs = stock.dividends
        div_history = []
        if not divs.empty:
            yearly = divs.groupby(divs.index.year).sum()
            for year, amount in yearly.tail(5).items():
                div_history.append({"y": str(year), "a": round(amount, 2)})

        result = {
            "n": info["name"],
            "en": info["en"],
            "s": info["sector"],
            "p": last_price,
            "ch": change_pct,
            "v": round(hist['Volume'].tail(5).mean() / 1e6, 1),
            "mc": market_cap,
            "pe": pe,
            "pb": pb,
            "dy": dy,
            "roe": roe,
            "de": round(de, 2),
            "bt": beta,
            "eps": eps,
            "fcf": fcf,
            "ds": div_safety,
            "sc": score,
            "rsi": int(rsi),
            "m50": ma50,
            "m200": ma200,
            "sp": support,
            "rs": resistance,
            "tr": trend,
            "nm": profit_margin,
            "ng": earnings_growth,
            "dg": revenue_growth,
            "pr": prices,
            "vl": volumes,
            "dh": div_history,
            "rev": revenue,
            "ni": net_income,
        }

        print(f"  ✓ {info['name']} ({ticker_code}): {last_price} ر.س ({change_pct:+.2f}%) | درجة: {score}")
        return result

    except Exception as e:
        print(f"  ✗ خطأ في {info['name']} ({ticker_code}): {e}")
        return None


def calculate_composite_score(pe, pb, roe, dy, beta, growth, div_safety, rsi, trend) -> int:
    """
    حساب الدرجة المركبة من 100

    العوامل:
    - القيمة (P/E, P/B): 20%
    - الجودة (ROE): 20%
    - النمو: 15%
    - التوزيعات: 15%
    - المخاطر (Beta): 15%
    - الزخم (RSI, Trend): 15%
    """
    score = 0

    # القيمة (20%)
    if pe > 0:
        if pe < 12: score += 20
        elif pe < 15: score += 16
        elif pe < 20: score += 12
        elif pe < 25: score += 8
        else: score += 4

    # الجودة (20%)
    if roe > 25: score += 20
    elif roe > 18: score += 16
    elif roe > 12: score += 12
    elif roe > 8: score += 8
    else: score += 4

    # النمو (15%)
    if growth > 15: score += 15
    elif growth > 10: score += 12
    elif growth > 5: score += 9
    elif growth > 0: score += 6
    else: score += 2

    # التوزيعات (15%)
    if dy > 5: score += 15
    elif dy > 3.5: score += 12
    elif dy > 2: score += 9
    elif dy > 1: score += 6
    else: score += 3

    # المخاطر (15%)
    if beta < 0.7: score += 15
    elif beta < 0.9: score += 12
    elif beta < 1.1: score += 9
    elif beta < 1.3: score += 6
    else: score += 3

    # الزخم (15%)
    if trend == "صاعد" and 40 < rsi < 70: score += 15
    elif trend == "صاعد": score += 12
    elif trend == "عرضي": score += 8
    else: score += 4

    return min(100, max(0, score))


def main():
    """النقطة الرئيسية للتشغيل"""
    print("=" * 60)
    print("  تداول بصيرة - جلب بيانات الأسهم السعودية")
    print("  Tadawul Baseera - Saudi Stock Data Pipeline")
    print("=" * 60)
    print(f"\n  عدد الأسهم: {len(SAUDI_STOCKS)}")
    print(f"  التاريخ: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"  المصدر: Yahoo Finance (.SR)")
    print("-" * 60)

    try:
        import yfinance
        print(f"  yfinance: {yfinance.__version__}")
    except ImportError:
        print("\n  ⚠ يجب تثبيت yfinance أولاً:")
        print("  pip install yfinance pandas --break-system-packages")
        print("\n  بعد التثبيت أعد تشغيل السكريبت.")

        # إنشاء ملف بيانات تجريبية
        print("\n  → إنشاء بيانات تجريبية...")
        create_sample_data()
        return

    print("\n  جاري جلب البيانات...\n")

    results = {}
    success = 0
    fail = 0

    for code, info in SAUDI_STOCKS.items():
        data = fetch_stock_data(code, info)
        if data:
            results[code] = data
            success += 1
        else:
            fail += 1

    # حفظ النتائج
    output_path = Path("saudi_stocks_data.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump({
            "updated": datetime.datetime.now().isoformat(),
            "source": "Yahoo Finance",
            "count": len(results),
            "stocks": results,
        }, f, ensure_ascii=False, indent=2)

    print(f"\n{'=' * 60}")
    print(f"  ✓ تم الانتهاء!")
    print(f"  نجح: {success} | فشل: {fail}")
    print(f"  الملف: {output_path.absolute()}")
    print(f"{'=' * 60}")


def create_sample_data():
    """إنشاء بيانات تجريبية عندما لا يتوفر yfinance"""
    import random

    results = {}
    for code, info in SAUDI_STOCKS.items():
        base_price = random.uniform(10, 200)
        results[code] = {
            "n": info["name"],
            "en": info["en"],
            "s": info["sector"],
            "p": round(base_price, 2),
            "ch": round(random.uniform(-3, 3), 2),
            "v": round(random.uniform(0.5, 20), 1),
            "mc": round(random.uniform(5, 500), 1),
            "pe": round(random.uniform(8, 30), 1),
            "pb": round(random.uniform(0.8, 5), 1),
            "dy": round(random.uniform(0, 7), 1),
            "roe": round(random.uniform(5, 35), 1),
            "de": round(random.uniform(0, 0.6), 2),
            "bt": round(random.uniform(0.5, 1.4), 2),
            "eps": round(random.uniform(0.5, 8), 2),
            "fcf": round(random.uniform(-1, 10), 1),
            "ds": random.randint(30, 95),
            "sc": random.randint(35, 90),
            "rsi": random.randint(25, 75),
            "m50": round(base_price * random.uniform(0.95, 1.05), 2),
            "m200": round(base_price * random.uniform(0.9, 1.1), 2),
            "sp": round(base_price * 0.95, 2),
            "rs": round(base_price * 1.05, 2),
            "tr": random.choice(["صاعد", "هابط", "عرضي"]),
            "nm": round(random.uniform(5, 40), 1),
            "ng": round(random.uniform(-10, 20), 1),
            "dg": round(random.uniform(-5, 15), 1),
            "pr": [round(base_price + random.uniform(-2, 2), 2) for _ in range(24)],
            "vl": [round(random.uniform(0.5, 10), 1) for _ in range(24)],
            "dh": [{"y": str(y), "a": round(random.uniform(0.5, 5), 2)} for y in range(2020, 2025)],
        }

    output_path = Path("saudi_stocks_data.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump({
            "updated": datetime.datetime.now().isoformat(),
            "source": "Sample Data",
            "count": len(results),
            "stocks": results,
        }, f, ensure_ascii=False, indent=2)

    print(f"  ✓ تم إنشاء بيانات تجريبية لـ {len(results)} سهم")
    print(f"  الملف: {output_path.absolute()}")


if __name__ == "__main__":
    main()
